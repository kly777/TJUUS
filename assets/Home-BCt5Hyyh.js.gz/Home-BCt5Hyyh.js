import{u as Jt,t as Ve,a as Gt,i as Qt,c as en,p as tn,d as N,h as _,b as ge,e as nn,r as I,o as rn,f as g,g as Me,j as Ue,k as on,l as x,m as v,n as V,q as xt,s as sn,V as et,v as tt,w as an,x as ln,T as un,y as nt,z as cn,A as dn,B as fn,C as xn,D as ie,E as vt,F as vn,G as pn,H as oe,I as rt,J as se,K as gn,L as pt,M as P,N as u,O as Ae,P as C,_ as W,Q,R as mn,S as De,U as me,W as je,X as Le,Y as hn,Z as Oe,$ as T}from"./index-CPOCpG9g.js";import{u as bn,_ as wn}from"./Creeper.vue_vue_type_script_setup_true_lang-Ch2Su1nq.js";import{N as _n}from"./Divider-i6Phy1xY.js";function yn(e){return Jt(Ve(e).toLowerCase())}function Sn(e,n,r,a){for(var i=-1,d=e==null?0:e.length;++i<d;)r=n(r,e[i],i,e);return r}function Cn(e){return function(n){return e==null?void 0:e[n]}}var Rn={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},kn=Cn(Rn),$n=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,zn="\\u0300-\\u036f",In="\\ufe20-\\ufe2f",Pn="\\u20d0-\\u20ff",Dn=zn+In+Pn,Tn="["+Dn+"]",Nn=RegExp(Tn,"g");function En(e){return e=Ve(e),e&&e.replace($n,kn).replace(Nn,"")}var An=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function On(e){return e.match(An)||[]}var Vn=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function Mn(e){return Vn.test(e)}var gt="\\ud800-\\udfff",Un="\\u0300-\\u036f",jn="\\ufe20-\\ufe2f",Ln="\\u20d0-\\u20ff",Bn=Un+jn+Ln,mt="\\u2700-\\u27bf",ht="a-z\\xdf-\\xf6\\xf8-\\xff",Wn="\\xac\\xb1\\xd7\\xf7",Zn="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Fn="\\u2000-\\u206f",Yn=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",bt="A-Z\\xc0-\\xd6\\xd8-\\xde",Xn="\\ufe0e\\ufe0f",wt=Wn+Zn+Fn+Yn,_t="['’]",ot="["+wt+"]",Hn="["+Bn+"]",yt="\\d+",Kn="["+mt+"]",St="["+ht+"]",Ct="[^"+gt+wt+yt+mt+ht+bt+"]",qn="\\ud83c[\\udffb-\\udfff]",Jn="(?:"+Hn+"|"+qn+")",Gn="[^"+gt+"]",Rt="(?:\\ud83c[\\udde6-\\uddff]){2}",kt="[\\ud800-\\udbff][\\udc00-\\udfff]",G="["+bt+"]",Qn="\\u200d",st="(?:"+St+"|"+Ct+")",er="(?:"+G+"|"+Ct+")",it="(?:"+_t+"(?:d|ll|m|re|s|t|ve))?",at="(?:"+_t+"(?:D|LL|M|RE|S|T|VE))?",$t=Jn+"?",zt="["+Xn+"]?",tr="(?:"+Qn+"(?:"+[Gn,Rt,kt].join("|")+")"+zt+$t+")*",nr="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",rr="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",or=zt+$t+tr,sr="(?:"+[Kn,Rt,kt].join("|")+")"+or,ir=RegExp([G+"?"+St+"+"+it+"(?="+[ot,G,"$"].join("|")+")",er+"+"+at+"(?="+[ot,G+st,"$"].join("|")+")",G+"?"+st+"+"+it,G+"+"+at,rr,nr,yt,sr].join("|"),"g");function ar(e){return e.match(ir)||[]}function lr(e,n,r){return e=Ve(e),n=n,n===void 0?Mn(e)?ar(e):On(e):e.match(n)||[]}var ur="['’]",cr=RegExp(ur,"g");function dr(e){return function(n){return Sn(lr(En(n).replace(cr,"")),e,"")}}var lt=dr(function(e,n,r){return n=n.toLowerCase(),e+(r?yn(n):n)});const It=en("n-carousel-methods");function fr(e){tn(It,e)}function Be(e="unknown",n="component"){const r=Qt(It);return r||Gt(e,`\`${n}\` must be placed inside \`n-carousel\`.`),r}function xr(){return _("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},_("g",{fill:"none"},_("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"})))}function vr(){return _("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},_("g",{fill:"none"},_("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"})))}const pr=N({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:n}=ge(e),{isVertical:r,isPrevDisabled:a,isNextDisabled:i,prev:d,next:S}=Be();return{mergedClsPrefix:n,isVertical:r,isPrevDisabled:a,isNextDisabled:i,prev:d,next:S}},render(){const{mergedClsPrefix:e}=this;return _("div",{class:`${e}-carousel__arrow-group`},_("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},xr()),_("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},vr()))}}),gr={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},mr=N({name:"CarouselDots",props:gr,setup(e){const{mergedClsPrefixRef:n}=ge(e),r=I([]),a=Be();function i(h,p){switch(h.key){case"Enter":case" ":h.preventDefault(),a.to(p);return}e.keyboard&&y(h)}function d(h){e.trigger==="hover"&&a.to(h)}function S(h){e.trigger==="click"&&a.to(h)}function y(h){var p;if(h.shiftKey||h.altKey||h.ctrlKey||h.metaKey)return;const w=(p=document.activeElement)===null||p===void 0?void 0:p.nodeName.toLowerCase();if(w==="input"||w==="textarea")return;const{code:$}=h,B=$==="PageUp"||$==="ArrowUp",Z=$==="PageDown"||$==="ArrowDown",k=$==="PageUp"||$==="ArrowRight",z=$==="PageDown"||$==="ArrowLeft",U=a.isVertical(),F=U?B:k,j=U?Z:z;!F&&!j||(h.preventDefault(),F&&!a.isNextDisabled()?(a.next(),R(a.currentIndexRef.value)):j&&!a.isPrevDisabled()&&(a.prev(),R(a.currentIndexRef.value)))}function R(h){var p;(p=r.value[h])===null||p===void 0||p.focus()}return rn(()=>r.value.length=0),{mergedClsPrefix:n,dotEls:r,handleKeydown:i,handleMouseenter:d,handleClick:S}},render(){const{mergedClsPrefix:e,dotEls:n}=this;return _("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},nn(this.total,r=>{const a=r===this.currentIndex;return _("div",{"aria-selected":a,ref:i=>n.push(i),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,a&&`${e}-carousel__dot--active`],key:r,onClick:()=>{this.handleClick(r)},onMouseenter:()=>{this.handleMouseenter(r)},onKeydown:i=>{this.handleKeydown(i,r)}})}))}}),pe="CarouselItem";function hr(e){var n;return((n=e.type)===null||n===void 0?void 0:n.name)===pe}const br=N({name:pe,setup(e){const{mergedClsPrefixRef:n}=ge(e),r=Be(lt(pe),`n-${lt(pe)}`),a=I(),i=g(()=>{const{value:p}=a;return p?r.getSlideIndex(p):-1}),d=g(()=>r.isPrev(i.value)),S=g(()=>r.isNext(i.value)),y=g(()=>r.isActive(i.value)),R=g(()=>r.getSlideStyle(i.value));Me(()=>{r.addSlide(a.value)}),Ue(()=>{r.removeSlide(a.value)});function h(p){const{value:w}=i;w!==void 0&&(r==null||r.onCarouselItemClick(w,p))}return{mergedClsPrefix:n,selfElRef:a,isPrev:d,isNext:S,isActive:y,index:i,style:R,handleClick:h}},render(){var e;const{$slots:n,mergedClsPrefix:r,isPrev:a,isNext:i,isActive:d,index:S,style:y}=this,R=[`${r}-carousel__slide`,{[`${r}-carousel__slide--current`]:d,[`${r}-carousel__slide--prev`]:a,[`${r}-carousel__slide--next`]:i}];return _("div",{ref:"selfElRef",class:R,role:"option",tabindex:"-1","data-index":S,"aria-hidden":!d,style:y,onClickCapture:this.handleClick},(e=n.default)===null||e===void 0?void 0:e.call(n,{isPrev:a,isNext:i,isActive:d,index:S}))}}),wr=on("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[x("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[x("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[V("> img",`
 display: block;
 `)])]),x("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[v("dot",[x("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[V("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 background-color: var(--n-dot-color-active);
 `)])]),v("line",[x("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[V("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),x("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[V("svg",`
 height: 1em;
 width: 1em;
 `),V("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),v("vertical",`
 touch-action: pan-x;
 `,[x("slides",`
 flex-direction: column;
 `),v("fade",[x("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),v("card",[x("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[v("current",`
 transform: translateY(-50%) translateZ(0);
 `),v("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),v("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),v("usercontrol",[x("slides",[V(">",[V("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),v("left",[x("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[v("line",[x("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),x("dot",`
 margin: 4px 0;
 `)]),x("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),v("vertical",[x("arrow",`
 transform: rotate(90deg);
 `)]),v("show-arrow",[v("bottom",[x("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),v("top",[x("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("left",[x("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("right",[x("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),v("left",[x("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[V("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("right",[x("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[v("line",[x("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),x("dot",`
 margin: 4px 0;
 `),x("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[V("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("top",[x("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[v("line",[x("dot",`
 margin: 0 4px;
 `)])]),x("dot",`
 margin: 0 4px;
 `),x("arrow-group",`
 top: 12px;
 right: 12px;
 `,[V("> *:first-child",`
 margin-right: 12px;
 `)])]),v("bottom",[x("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[v("line",[x("dot",`
 margin: 0 4px;
 `)])]),x("dot",`
 margin: 0 4px;
 `),x("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[V("> *:first-child",`
 margin-right: 12px;
 `)])]),v("fade",[x("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[v("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),v("card",[x("slides",`
 perspective: 1000px;
 `),x("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[v("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),v("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),v("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]);function _r(e){const{length:n}=e;return n>1&&(e.push(ut(e[0],0,"append")),e.unshift(ut(e[n-1],n-1,"prepend"))),e}function ut(e,n,r){return xt(e,{key:`carousel-item-duplicate-${n}-${r}`})}function ct(e,n,r){return n===1?0:r?e===0?n-3:e===n-1?0:e-1:e}function Te(e,n){return n?e+1:e}function yr(e,n,r){return e<0?null:e===0?r?n-1:null:e-1}function Sr(e,n,r){return e>n-1?null:e===n-1?r?0:null:e+1}function Cr(e,n){return n&&e>3?e-2:e}function dt(e){return window.TouchEvent&&e instanceof window.TouchEvent}function ft(e,n){let{offsetWidth:r,offsetHeight:a}=e;if(n){const i=getComputedStyle(e);r=r-Number.parseFloat(i.getPropertyValue("padding-left"))-Number.parseFloat(i.getPropertyValue("padding-right")),a=a-Number.parseFloat(i.getPropertyValue("padding-top"))-Number.parseFloat(i.getPropertyValue("padding-bottom"))}return{width:r,height:a}}function ve(e,n,r){return e<n?n:e>r?r:e}function Rr(e){if(e===void 0)return 0;if(typeof e=="number")return e;const n=/^((\d+)?\.?\d+?)(ms|s)?$/,r=e.match(n);if(r){const[,a,,i="ms"]=r;return Number(a)*(i==="ms"?1:1e3)}return 0}const kr=["transitionDuration","transitionTimingFunction"],$r=Object.assign(Object.assign({},vt.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ne=!1;const zr=N({name:"Carousel",props:$r,slots:Object,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:r}=ge(e),a=I(null),i=I(null),d=I([]),S={value:[]},y=g(()=>e.direction==="vertical"),R=g(()=>y.value?"height":"width"),h=g(()=>y.value?"bottom":"right"),p=g(()=>e.effect==="slide"),w=g(()=>e.loop&&e.slidesPerView===1&&p.value),$=g(()=>e.effect==="custom"),B=g(()=>!p.value||e.centeredSlides?1:e.slidesPerView),Z=g(()=>$.value?1:e.slidesPerView),k=g(()=>B.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),z=I({width:0,height:0}),U=I(0),F=g(()=>{const{value:t}=d;if(!t.length)return[];U.value;const{value:o}=k;if(o)return t.map(b=>ft(b));const{value:s}=Z,{value:c}=z,{value:f}=R;let l=c[f];if(s!=="auto"){const{spaceBetween:b}=e,D=l-(s-1)*b,xe=1/Math.max(1,s);l=D*xe}const m=Object.assign(Object.assign({},c),{[f]:l});return t.map(()=>m)}),j=g(()=>{const{value:t}=F;if(!t.length)return[];const{centeredSlides:o,spaceBetween:s}=e,{value:c}=R,{[c]:f}=z.value;let l=0;return t.map(({[c]:m})=>{let b=l;return o&&(b+=(m-f)/2),l+=m+s,b})}),Ze=I(!1),he=g(()=>{const{transitionStyle:t}=e;return t?nt(t,kr):{}}),be=g(()=>$.value?0:Rr(he.value.transitionDuration)),Fe=g(()=>{const{value:t}=d;if(!t.length)return[];const o=!(k.value||Z.value===1),s=m=>{if(o){const{value:b}=R;return{[b]:`${F.value[m][b]}px`}}};if($.value)return t.map((m,b)=>s(b));const{effect:c,spaceBetween:f}=e,{value:l}=h;return t.reduce((m,b,D)=>{const xe=Object.assign(Object.assign({},s(D)),{[`margin-${l}`]:`${f}px`});return m.push(xe),Ze.value&&(c==="fade"||c==="card")&&Object.assign(xe,he.value),m},[])}),E=g(()=>{const{value:t}=B,{length:o}=d.value;if(t!=="auto")return Math.max(o-t,0)+1;{const{value:s}=F,{length:c}=s;if(!c)return o;const{value:f}=j,{value:l}=R,m=z.value[l];let b=s[s.length-1][l],D=c;for(;D>1&&b<m;)D--,b+=f[D]-f[D-1];return ve(D+1,1,c)}}),we=g(()=>Cr(E.value,w.value)),Pt=Te(e.defaultIndex,w.value),_e=I(ct(Pt,E.value,w.value)),M=cn(dn(e,"currentIndex"),_e),A=g(()=>Te(M.value,w.value));function ee(t){var o,s;t=ve(t,0,E.value-1);const c=ct(t,E.value,w.value),{value:f}=M;c!==M.value&&(_e.value=c,(o=e["onUpdate:currentIndex"])===null||o===void 0||o.call(e,c,f),(s=e.onUpdateCurrentIndex)===null||s===void 0||s.call(e,c,f))}function ye(t=A.value){return yr(t,E.value,e.loop)}function Se(t=A.value){return Sr(t,E.value,e.loop)}function Dt(t){const o=H(t);return o!==null&&ye()===o}function Tt(t){const o=H(t);return o!==null&&Se()===o}function Ye(t){return A.value===H(t)}function Nt(t){return M.value===t}function Xe(){return ye()===null}function He(){return Se()===null}let X=0;function Ce(t){const o=ve(Te(t,w.value),0,E.value);(t!==M.value||o!==A.value)&&ee(o)}function ae(){const t=ye();t!==null&&(X=-1,ee(t))}function te(){const t=Se();t!==null&&(X=1,ee(t))}let O=!1;function Et(){(!O||!w.value)&&ae()}function At(){(!O||!w.value)&&te()}let Y=0;const Re=I({});function le(t,o=0){Re.value=Object.assign({},he.value,{transform:y.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${o}ms`})}function ne(t=0){p.value?ke(A.value,t):Y!==0&&(!O&&t>0&&(O=!0),le(Y=0,t))}function ke(t,o){const s=Ke(t);s!==Y&&o>0&&(O=!0),Y=Ke(A.value),le(s,o)}function Ke(t){let o;return t>=E.value-1?o=qe():o=j.value[t]||0,o}function qe(){if(B.value==="auto"){const{value:t}=R,{[t]:o}=z.value,{value:s}=j,c=s[s.length-1];let f;if(c===void 0)f=o;else{const{value:l}=F;f=c+l[l.length-1][t]}return f-o}else{const{value:t}=j;return t[E.value-1]||0}}const re={currentIndexRef:M,to:Ce,prev:Et,next:At,isVertical:()=>y.value,isHorizontal:()=>!y.value,isPrev:Dt,isNext:Tt,isActive:Ye,isPrevDisabled:Xe,isNextDisabled:He,getSlideIndex:H,getSlideStyle:Mt,addSlide:Ot,removeSlide:Vt,onCarouselItemClick:Ut};fr(re);function Ot(t){t&&d.value.push(t)}function Vt(t){if(!t)return;const o=H(t);o!==-1&&d.value.splice(o,1)}function H(t){return typeof t=="number"?t:t?d.value.indexOf(t):-1}function Mt(t){const o=H(t);if(o!==-1){const s=[Fe.value[o]],c=re.isPrev(o),f=re.isNext(o);return c&&s.push(e.prevSlideStyle||""),f&&s.push(e.nextSlideStyle||""),pt(s)}}let $e=0,ze=0,L=0,Ie=0,ue=!1,Pe=!1;function Ut(t,o){let s=!O&&!ue&&!Pe;e.effect==="card"&&s&&!Ye(t)&&(Ce(t),s=!1),s||(o.preventDefault(),o.stopPropagation())}let ce=null;function de(){ce&&(clearInterval(ce),ce=null)}function K(){de(),!e.autoplay||we.value<2||(ce=window.setInterval(te,e.interval))}function Je(t){var o;if(Ne||!(!((o=i.value)===null||o===void 0)&&o.contains(pn(t))))return;Ne=!0,ue=!0,Pe=!1,Ie=Date.now(),de(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const s=dt(t)?t.touches[0]:t;y.value?ze=s.clientY:$e=s.clientX,e.touchable&&(oe("touchmove",document,fe),oe("touchend",document,q),oe("touchcancel",document,q)),e.draggable&&(oe("mousemove",document,fe),oe("mouseup",document,q))}function fe(t){const{value:o}=y,{value:s}=R,c=dt(t)?t.touches[0]:t,f=o?c.clientY-ze:c.clientX-$e,l=z.value[s];L=ve(f,-l,l),t.cancelable&&t.preventDefault(),p.value&&le(Y-L,0)}function q(){const{value:t}=A;let o=t;if(!O&&L!==0&&p.value){const s=Y-L,c=[...j.value.slice(0,E.value-1),qe()];let f=null;for(let l=0;l<c.length;l++){const m=Math.abs(c[l]-s);if(f!==null&&f<m)break;f=m,o=l}}if(o===t){const s=Date.now()-Ie,{value:c}=R,f=z.value[c];L>f/2||L/s>.4?ae():(L<-f/2||L/s<-.4)&&te()}o!==null&&o!==t?(Pe=!0,ee(o),rt(()=>{(!w.value||_e.value!==M.value)&&ne(be.value)})):ne(be.value),Ge(),K()}function Ge(){ue&&(Ne=!1),ue=!1,$e=0,ze=0,L=0,Ie=0,se("touchmove",document,fe),se("touchend",document,q),se("touchcancel",document,q),se("mousemove",document,fe),se("mouseup",document,q)}function jt(){if(p.value&&O){const{value:t}=A;ke(t,0)}else K();p.value&&(Re.value.transitionDuration="0ms"),O=!1}function Lt(t){if(t.preventDefault(),O)return;let{deltaX:o,deltaY:s}=t;t.shiftKey&&!o&&(o=s);const c=-1,f=1,l=(o||s)>0?f:c;let m=0,b=0;y.value?b=l:m=l;const D=10;(b*s>=D||m*o>=D)&&(l===f&&!He()?te():l===c&&!Xe()&&ae())}function Bt(){z.value=ft(a.value,!0),K()}function Wt(){k.value&&U.value++}function Zt(){e.autoplay&&de()}function Ft(){e.autoplay&&K()}Me(()=>{fn(K),requestAnimationFrame(()=>Ze.value=!0)}),Ue(()=>{Ge(),de()}),xn(()=>{const{value:t}=d,{value:o}=S,s=new Map,c=l=>s.has(l)?s.get(l):-1;let f=!1;for(let l=0;l<t.length;l++){const m=o.findIndex(b=>b.el===t[l]);m!==l&&(f=!0),s.set(t[l],m)}f&&t.sort((l,m)=>c(l)-c(m))}),ie(A,(t,o)=>{if(t===o){X=0;return}if(K(),p.value){if(w.value){const{value:s}=E;X===-1&&o===1&&t===s-2?t=0:X===1&&o===s-2&&t===1&&(t=s-1)}ke(t,be.value)}else ne();X=0},{immediate:!0}),ie([w,B],()=>void rt(()=>{ee(A.value)})),ie(j,()=>{p.value&&ne()},{deep:!0}),ie(p,t=>{t?ne():(O=!1,le(Y=0))});const Yt=g(()=>({onTouchstartPassive:e.touchable?Je:void 0,onMousedown:e.draggable?Je:void 0,onWheel:e.mousewheel?Lt:void 0})),Xt=g(()=>Object.assign(Object.assign({},nt(re,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:we.value,currentIndex:M.value})),Ht=g(()=>({total:we.value,currentIndex:M.value,to:re.to})),Kt={getCurrentIndex:()=>M.value,to:Ce,prev:ae,next:te},qt=vt("Carousel","-carousel",wr,gn,e,n),Qe=g(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:o,dotColor:s,dotColorActive:c,dotColorFocus:f,dotLineWidth:l,dotLineWidthActive:m,arrowColor:b}}=qt.value;return{"--n-bezier":t,"--n-dot-color":s,"--n-dot-color-focus":f,"--n-dot-color-active":c,"--n-dot-size":o,"--n-dot-line-width":l,"--n-dot-line-width-active":m,"--n-arrow-color":b}}),J=r?vn("carousel",void 0,Qe,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:n,selfElRef:a,slidesElRef:i,slideVNodes:S,duplicatedable:w,userWantsControl:$,autoSlideSize:k,realIndex:A,slideStyles:Fe,translateStyle:Re,slidesControlListeners:Yt,handleTransitionEnd:jt,handleResize:Bt,handleSlideResize:Wt,handleMouseenter:Zt,handleMouseleave:Ft,isActive:Nt,arrowSlotProps:Xt,dotSlotProps:Ht},Kt),{cssVars:r?void 0:Qe,themeClass:J==null?void 0:J.themeClass,onRender:J==null?void 0:J.onRender})},render(){var e;const{mergedClsPrefix:n,showArrow:r,userWantsControl:a,slideStyles:i,dotType:d,dotPlacement:S,slidesControlListeners:y,transitionProps:R={},arrowSlotProps:h,dotSlotProps:p,$slots:{default:w,dots:$,arrow:B}}=this,Z=w&&sn(w())||[];let k=Ir(Z);return k.length||(k=Z.map(z=>_(br,null,{default:()=>xt(z)}))),this.duplicatedable&&(k=_r(k)),this.slideVNodes.value=k,this.autoSlideSize&&(k=k.map(z=>_(et,{onResize:this.handleSlideResize},{default:()=>z}))),(e=this.onRender)===null||e===void 0||e.call(this),_("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${n}-carousel`,this.direction==="vertical"&&`${n}-carousel--vertical`,this.showArrow&&`${n}-carousel--show-arrow`,`${n}-carousel--${S}`,`${n}-carousel--${this.direction}`,`${n}-carousel--${this.effect}`,a&&`${n}-carousel--usercontrol`],style:this.cssVars},y,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),_(et,{onResize:this.handleResize},{default:()=>_("div",{ref:"slidesElRef",class:`${n}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},a?k.map((z,U)=>_("div",{style:i[U],key:U},an(_(un,Object.assign({},R),{default:()=>z}),[[ln,this.isActive(U)]]))):k)}),this.showDots&&p.total>1&&tt($,p,()=>[_(mr,{key:d+S,total:p.total,currentIndex:p.currentIndex,dotType:d,trigger:this.trigger,keyboard:this.keyboard})]),r&&tt(B,h,()=>[_(pr,null)]))}});function Ir(e){return e.reduce((n,r)=>(hr(r)&&n.push(r),n),[])}const Pr={class:"home-container animate__animated animate__pulse"},Dr=N({__name:"PageBanner",setup(e){const n=I(),{y:r}=bn();return ie(r,a=>{n.value.style.transform=`translateY(${-a/6}px)`}),(a,i)=>(C(),P("div",Pr,[i[0]||(i[0]=u("div",{class:"logo animate__animated animate__fadeInUp pointer-events-none"},[u("div",{class:"title mx-auto"},[u("div",{class:"text-9xl sm:text-100px md:text-120px lg:text-140px scale-x-115"},"TJUUS")]),u("div",{class:"describe"},[Ae("TianJinUniversity"),u("br"),Ae("UnitedServer")])],-1)),u("div",{class:"background",ref_key:"background",ref:n},null,512)]))}}),Tr=W(Dr,[["__scopeId","data-v-5895cfd5"]]),Nr={},Er={class:"bg flex justify-center items-center h-[100px] w-[85%] mt-5 rounded-3xl relative bg-cover bg-center hover:scale-105 transition-all"};function Ar(e,n){return C(),P("div",Er,n[0]||(n[0]=[u("div",{class:"tip-text absolute sm:text-3xl text-xl font-bold text-white pointer-events-none transition-all duration-300 ease-in-out"}," #网站正在施工中...... ",-1)]))}const Or=W(Nr,[["render",Ar],["__scopeId","data-v-fa21c669"]]),Vr={class:"mb-10"},Mr={class:"text-center font-semibold text-blue-400 dark:text-blue-300 text-xl sm:text-2xl md:text-3xl lg:text-4xl opacity-80"},Ur={class:"text-center italic relative text-lg sm:text-xl mt-[-15px] text-sky-700 dark:text-blue-200"},Ee=N({__name:"SectionTitle",props:{main:String,sub:String},setup(e){return(n,r)=>(C(),P("div",Vr,[u("div",Mr,Q(e.main),1),u("div",Ur,Q(e.sub),1)]))}}),jr={class:"flex flex-col md:flex-row md:h-55 p-0"},Lr=["src"],Br={class:"text-xl font-bold mb-2"},Wr=N({__name:"InfoCard",props:{imageSrc:{type:String,required:!0},title:{type:String,required:!0},description:{type:String,required:!0},imageOnRight:{type:Boolean,default:!1}},setup(e){const n=mn();function r(){const d={社团简介:"ClubIntro",卫津路校区复刻项目:"WeijinluProject",北洋园校区复刻项目:"BeiyangyuanProject",运营周报:"WeeklyReport",新闻报道:"NewsReport"};d[i.title]?n.push({name:d[i.title]}):console.warn(`未找到标题"${i.title}"对应的路由`)}function a(d){return d.slice(0,30)+(d.length>30?"......":"")}const i=e;return(d,S)=>(C(),P("div",{onClick:r,class:"card border border-solid border-zinc-200 rounded-lg shadow-lg border-opacity-20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-white bg-white transition-all duration-500 ease-in-out hover:scale-105 lg:w-4/5 max-w-[780px] box-border"},[u("div",jr,[u("div",{class:De(["w-full md:w-1/2",{"md:order-2":e.imageOnRight,"order-1":!e.imageOnRight}])},[u("img",{src:i.imageSrc,class:De(["w-full h-full object-cover",{"rounded-t-lg md:rounded-l-lg md:rounded-tr-none":!e.imageOnRight,"rounded-t-lg md:rounded-r-lg md:rounded-tl-none":e.imageOnRight}])},null,10,Lr)],2),u("div",{class:De(["w-full md:w-1/2 px-6 py-4 min-h-40 text-black dark:text-white",{"order-1":e.imageOnRight,"order-2":!e.imageOnRight}])},[u("h2",Br,Q(i.title),1),u("p",null,Q(a(i.description)),1)],2)])]))}}),Zr=[{imageSrc:"server/tianda1.png",title:"社团简介",description:"天津大学卫津路校区复刻项目社团介绍"},{imageSrc:"building/图书馆.png",title:"卫津路校区复刻项目",description:"卫津路校区标志性建筑数字化复刻工程"},{imageSrc:"building/北洋广场.png",title:"北洋园校区复刻项目",description:"北洋园校区核心区域三维建模与场景还原"},{imageSrc:"server/tianda2.png",title:"运营周报",description:"复刻项目每周进度与技术指标报告"},{imageSrc:"server/tianda2.png",title:"新闻报道",description:"项目进展与校园文化传承动态资讯"}],Fr=["eg/1.png","eg/2.png","eg/0.png","eg/5.png","eg/7.png","eg/8.png"],Yr=[{imageSrc:"building/eastDoor.png",title:"东大门",description:"北洋"},{imageSrc:"building/shiShi.png",title:"北洋广场",description:"实事求是"},{imageSrc:"building/胡.png",title:"求是亭",description:"求真务实"},{imageSrc:"building/水塔.png",title:"校史馆",description:"百卅天大"}],We={server:Zr,carousel:Fr,building:Yr},Xr={class:"servers-container sm:w-85% box-border"},Hr={class:"grid place-items-center"},Kr=N({__name:"InfoCards",setup(e){const n=I(We.server);return(r,a)=>(C(),P("div",Xr,[u("div",Hr,[(C(!0),P(me,null,je(n.value,(i,d)=>(C(),Le(Wr,{key:d,imageSrc:i.imageSrc,title:i.title,description:i.description,imageOnRight:d%2===1},null,8,["imageSrc","title","description","imageOnRight"]))),128))])]))}}),qr=W(Kr,[["__scopeId","data-v-93140b40"]]),Jr={class:"component p-4"},Gr={class:"flex justify-center items-center"},Qr={class:"text-2xl font-semibold mb-2 text-center mt-5 text-zinc-800 dark:text-blue-400"},eo={class:"text-center text-sm dark:text-blue-300"},to=N({__name:"FeaturedItem",props:{title:{type:String,required:!0},description:{type:String,required:!0},imageSrc:{type:String,required:!0}},setup(e){return(n,r)=>(C(),P("div",Jr,[u("div",Gr,[u("div",{class:"bg-cover w-full aspect-[1/0.55] rounded-lg hover:scale-105 transition-all duration-300 border-white dark:border-zinc-900",style:pt({backgroundImage:`url(${e.imageSrc})`})},null,4)]),u("h2",Qr,Q(e.title),1),u("p",eo,Q(e.description),1)]))}}),no={class:"building-container"},ro={class:"grid",style:{gridTemplateColumns:"repeat(auto-fit, minmax(250px, 1fr))"}},oo=N({__name:"FeaturedItems",setup(e){const n=I(We.building);return(r,a)=>(C(),P("div",no,[u("div",ro,[(C(!0),P(me,null,je(n.value,(i,d)=>(C(),Le(to,{key:d,imageSrc:i.imageSrc,title:i.title,description:i.description},null,8,["imageSrc","title","description"]))),128))])]))}}),so=W(oo,[["__scopeId","data-v-342f42e6"]]),io=["src"],ao=N({__name:"Carousel",setup(e){const n=I(1),r=We.carousel;function a(){n.value=window.innerWidth>768?3:1}return Me(()=>{a(),window.addEventListener("resize",a)}),Ue(()=>{window.removeEventListener("resize",a)}),(i,d)=>(C(),Le(Oe(zr),{autoplay:"","slides-per-view":n.value,"space-between":20},{default:hn(()=>[(C(!0),P(me,null,je(Oe(r),(S,y)=>(C(),P("img",{key:y,class:"carousel-img",src:S},null,8,io))),128))]),_:1},8,["slides-per-view"]))}}),lo=W(ao,[["__scopeId","data-v-98943961"]]),uo={},co={class:"back-img relative sm:h-[500px] h-[300px] w-screen bg-fixed bg-[50%_80%] bg-auto"};function fo(e,n){return C(),P("div",co,n[0]||(n[0]=[u("div",{class:"absolute inset-0 bg-opacity-70 z-[0.5]"},null,-1),u("div",{class:"text-white relative"},[u("div",{class:"z-[1] absolute overflow-hidden sm:h-[500px] w-screen h-[300px] p-[30px] pl-15 box-border flex flex-col items-start flex-wrap text-2xl gap-y-3.5"},[u("h1",null,"TJUUS"),u("h2",null,"是一个"),u("h2",null,"人很多"),u("h2",null,"的"),u("h2",null,"社团")])],-1)]))}const xo=W(uo,[["render",fo],["__scopeId","data-v-7bcb5739"]]),vo="/TJUUS/icon/bili.png",po={},go={class:"follow-container"};function mo(e,n){return C(),P("div",go,n[0]||(n[0]=[u("div",{class:"overlay"},[u("h1",null,"关注我们!!!!!"),u("p",null,[u("a",{href:"https://space.bilibili.com/1343371808",target:"_blank",class:"text-white flex items-center justify-center decoration-none"},[u("img",{src:vo,alt:"bilibili Logo",class:"h-7 mr-2"}),Ae(" bilibili ")])])],-1)]))}const ho=W(po,[["render",mo],["__scopeId","data-v-adb5bdbb"]]),bo={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-[85%] py-8"},wo={class:"grid sc box-border justify-center items-center sm:mx-7 mx-9"},_o={class:"grid-cols-1"},yo={class:"h-auto w-0 justify-self-start creeper"},So={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-80% py-8"},Co={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-5 w-80% py-8"},Ro=N({__name:"Home",setup(e){return(n,r)=>(C(),P(me,null,[T(Tr),u("section",bo,[T(Or,{class:"developing"})]),T(Oe(_n),{dashed:!0}),u("section",wo,[u("div",_o,[T(qr,{class:"row lg:w-80%"})]),u("div",yo,[T(wn,{class:"sm:h-[350px] sm:w-[300px] md:h-[400px] md:w-[400px] lg:h-[550px] lg:w-[550px] h-[260px] w-[250px]"})])]),u("section",So,[T(Ee,{class:"row my",main:"我们是",sub:"TJUUS"})]),T(xo),u("section",Co,[T(Ee,{class:"row my",main:"建设成果",sub:"探索Minecraft的无限可能"}),T(so,{class:"row"}),T(Ee,{class:"row my-5",main:"我们的伙伴",sub:"联合"}),T(lo,{class:"row my-5"})]),T(ho,{class:"mt"})],64))}}),Io=W(Ro,[["__scopeId","data-v-243f4c3a"]]);export{Io as default};
