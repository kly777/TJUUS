import{u as Jt,t as Oe,a as Gt,i as Qt,c as en,p as tn,d as M,h as _,b as ge,e as nn,r as I,o as rn,f as g,g as Ve,j as Me,k as sn,l as f,m as v,n as O,q as ft,s as on,V as Qe,v as et,w as an,x as ln,T as un,y as tt,z as cn,A as dn,B as fn,C as vn,D as ae,E as vt,F as xn,G as pn,H as gn,I as se,J as nt,K as oe,L as xt,M as P,N as u,O as Ae,P as S,_ as Z,Q,R as De,S as me,U as Ue,W as je,X as mn,Y as pt,Z as T}from"./index-BUGQ8vM2.js";import{u as hn,_ as bn}from"./Creeper.vue_vue_type_script_setup_true_lang-QEOF79SX.js";import{N as wn}from"./Divider-edWwKKy7.js";function _n(e){return Jt(Oe(e).toLowerCase())}function yn(e,n,r,a){for(var i=-1,p=e==null?0:e.length;++i<p;)r=n(r,e[i],i,e);return r}function Sn(e){return function(n){return e==null?void 0:e[n]}}var Cn={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},Rn=Sn(Cn),zn=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,$n="\\u0300-\\u036f",kn="\\ufe20-\\ufe2f",In="\\u20d0-\\u20ff",Pn=$n+kn+In,Dn="["+Pn+"]",Tn=RegExp(Dn,"g");function Nn(e){return e=Oe(e),e&&e.replace(zn,Rn).replace(Tn,"")}var En=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function An(e){return e.match(En)||[]}var On=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function Vn(e){return On.test(e)}var gt="\\ud800-\\udfff",Mn="\\u0300-\\u036f",Un="\\ufe20-\\ufe2f",jn="\\u20d0-\\u20ff",Ln=Mn+Un+jn,mt="\\u2700-\\u27bf",ht="a-z\\xdf-\\xf6\\xf8-\\xff",Bn="\\xac\\xb1\\xd7\\xf7",Zn="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Wn="\\u2000-\\u206f",Fn=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",bt="A-Z\\xc0-\\xd6\\xd8-\\xde",Yn="\\ufe0e\\ufe0f",wt=Bn+Zn+Wn+Fn,_t="['’]",rt="["+wt+"]",Xn="["+Ln+"]",yt="\\d+",Hn="["+mt+"]",St="["+ht+"]",Ct="[^"+gt+wt+yt+mt+ht+bt+"]",Kn="\\ud83c[\\udffb-\\udfff]",qn="(?:"+Xn+"|"+Kn+")",Jn="[^"+gt+"]",Rt="(?:\\ud83c[\\udde6-\\uddff]){2}",zt="[\\ud800-\\udbff][\\udc00-\\udfff]",G="["+bt+"]",Gn="\\u200d",st="(?:"+St+"|"+Ct+")",Qn="(?:"+G+"|"+Ct+")",ot="(?:"+_t+"(?:d|ll|m|re|s|t|ve))?",at="(?:"+_t+"(?:D|LL|M|RE|S|T|VE))?",$t=qn+"?",kt="["+Yn+"]?",er="(?:"+Gn+"(?:"+[Jn,Rt,zt].join("|")+")"+kt+$t+")*",tr="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",nr="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",rr=kt+$t+er,sr="(?:"+[Hn,Rt,zt].join("|")+")"+rr,or=RegExp([G+"?"+St+"+"+ot+"(?="+[rt,G,"$"].join("|")+")",Qn+"+"+at+"(?="+[rt,G+st,"$"].join("|")+")",G+"?"+st+"+"+ot,G+"+"+at,nr,tr,yt,sr].join("|"),"g");function ar(e){return e.match(or)||[]}function ir(e,n,r){return e=Oe(e),n=n,n===void 0?Vn(e)?ar(e):An(e):e.match(n)||[]}var lr="['’]",ur=RegExp(lr,"g");function cr(e){return function(n){return yn(ir(Nn(n).replace(ur,"")),e,"")}}var it=cr(function(e,n,r){return n=n.toLowerCase(),e+(r?_n(n):n)});const It=en("n-carousel-methods");function dr(e){tn(It,e)}function Le(e="unknown",n="component"){const r=Qt(It);return r||Gt(e,`\`${n}\` must be placed inside \`n-carousel\`.`),r}function fr(){return _("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},_("g",{fill:"none"},_("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"})))}function vr(){return _("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},_("g",{fill:"none"},_("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"})))}const xr=M({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:n}=ge(e),{isVertical:r,isPrevDisabled:a,isNextDisabled:i,prev:p,next:C}=Le();return{mergedClsPrefix:n,isVertical:r,isPrevDisabled:a,isNextDisabled:i,prev:p,next:C}},render(){const{mergedClsPrefix:e}=this;return _("div",{class:`${e}-carousel__arrow-group`},_("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},fr()),_("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},vr()))}}),pr={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},gr=M({name:"CarouselDots",props:pr,setup(e){const{mergedClsPrefixRef:n}=ge(e),r=I([]),a=Le();function i(h,x){switch(h.key){case"Enter":case" ":h.preventDefault(),a.to(x);return}e.keyboard&&y(h)}function p(h){e.trigger==="hover"&&a.to(h)}function C(h){e.trigger==="click"&&a.to(h)}function y(h){var x;if(h.shiftKey||h.altKey||h.ctrlKey||h.metaKey)return;const w=(x=document.activeElement)===null||x===void 0?void 0:x.nodeName.toLowerCase();if(w==="input"||w==="textarea")return;const{code:$}=h,B=$==="PageUp"||$==="ArrowUp",W=$==="PageDown"||$==="ArrowDown",z=$==="PageUp"||$==="ArrowRight",k=$==="PageDown"||$==="ArrowLeft",U=a.isVertical(),F=U?B:z,j=U?W:k;!F&&!j||(h.preventDefault(),F&&!a.isNextDisabled()?(a.next(),R(a.currentIndexRef.value)):j&&!a.isPrevDisabled()&&(a.prev(),R(a.currentIndexRef.value)))}function R(h){var x;(x=r.value[h])===null||x===void 0||x.focus()}return rn(()=>r.value.length=0),{mergedClsPrefix:n,dotEls:r,handleKeydown:i,handleMouseenter:p,handleClick:C}},render(){const{mergedClsPrefix:e,dotEls:n}=this;return _("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},nn(this.total,r=>{const a=r===this.currentIndex;return _("div",{"aria-selected":a,ref:i=>n.push(i),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,a&&`${e}-carousel__dot--active`],key:r,onClick:()=>{this.handleClick(r)},onMouseenter:()=>{this.handleMouseenter(r)},onKeydown:i=>{this.handleKeydown(i,r)}})}))}}),pe="CarouselItem";function mr(e){var n;return((n=e.type)===null||n===void 0?void 0:n.name)===pe}const hr=M({name:pe,setup(e){const{mergedClsPrefixRef:n}=ge(e),r=Le(it(pe),`n-${it(pe)}`),a=I(),i=g(()=>{const{value:x}=a;return x?r.getSlideIndex(x):-1}),p=g(()=>r.isPrev(i.value)),C=g(()=>r.isNext(i.value)),y=g(()=>r.isActive(i.value)),R=g(()=>r.getSlideStyle(i.value));Ve(()=>{r.addSlide(a.value)}),Me(()=>{r.removeSlide(a.value)});function h(x){const{value:w}=i;w!==void 0&&(r==null||r.onCarouselItemClick(w,x))}return{mergedClsPrefix:n,selfElRef:a,isPrev:p,isNext:C,isActive:y,index:i,style:R,handleClick:h}},render(){var e;const{$slots:n,mergedClsPrefix:r,isPrev:a,isNext:i,isActive:p,index:C,style:y}=this,R=[`${r}-carousel__slide`,{[`${r}-carousel__slide--current`]:p,[`${r}-carousel__slide--prev`]:a,[`${r}-carousel__slide--next`]:i}];return _("div",{ref:"selfElRef",class:R,role:"option",tabindex:"-1","data-index":C,"aria-hidden":!p,style:y,onClickCapture:this.handleClick},(e=n.default)===null||e===void 0?void 0:e.call(n,{isPrev:a,isNext:i,isActive:p,index:C}))}}),br=sn("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[f("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[f("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[O("> img",`
 display: block;
 `)])]),f("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[v("dot",[f("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[O("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 background-color: var(--n-dot-color-active);
 `)])]),v("line",[f("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[O("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),v("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),f("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[O("svg",`
 height: 1em;
 width: 1em;
 `),O("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),v("vertical",`
 touch-action: pan-x;
 `,[f("slides",`
 flex-direction: column;
 `),v("fade",[f("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),v("card",[f("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[v("current",`
 transform: translateY(-50%) translateZ(0);
 `),v("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),v("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),v("usercontrol",[f("slides",[O(">",[O("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),v("left",[f("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[v("line",[f("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),f("dot",`
 margin: 4px 0;
 `)]),f("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),v("vertical",[f("arrow",`
 transform: rotate(90deg);
 `)]),v("show-arrow",[v("bottom",[f("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),v("top",[f("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("left",[f("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),v("right",[f("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),v("left",[f("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[O("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("right",[f("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[v("line",[f("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[v("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),f("dot",`
 margin: 4px 0;
 `),f("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[O("> *:first-child",`
 margin-bottom: 12px;
 `)])]),v("top",[f("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[v("line",[f("dot",`
 margin: 0 4px;
 `)])]),f("dot",`
 margin: 0 4px;
 `),f("arrow-group",`
 top: 12px;
 right: 12px;
 `,[O("> *:first-child",`
 margin-right: 12px;
 `)])]),v("bottom",[f("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[v("line",[f("dot",`
 margin: 0 4px;
 `)])]),f("dot",`
 margin: 0 4px;
 `),f("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[O("> *:first-child",`
 margin-right: 12px;
 `)])]),v("fade",[f("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[v("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),v("card",[f("slides",`
 perspective: 1000px;
 `),f("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[v("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),v("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),v("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]);function wr(e){const{length:n}=e;return n>1&&(e.push(lt(e[0],0,"append")),e.unshift(lt(e[n-1],n-1,"prepend"))),e}function lt(e,n,r){return ft(e,{key:`carousel-item-duplicate-${n}-${r}`})}function ut(e,n,r){return n===1?0:r?e===0?n-3:e===n-1?0:e-1:e}function Te(e,n){return n?e+1:e}function _r(e,n,r){return e<0?null:e===0?r?n-1:null:e-1}function yr(e,n,r){return e>n-1?null:e===n-1?r?0:null:e+1}function Sr(e,n){return n&&e>3?e-2:e}function ct(e){return window.TouchEvent&&e instanceof window.TouchEvent}function dt(e,n){let{offsetWidth:r,offsetHeight:a}=e;if(n){const i=getComputedStyle(e);r=r-Number.parseFloat(i.getPropertyValue("padding-left"))-Number.parseFloat(i.getPropertyValue("padding-right")),a=a-Number.parseFloat(i.getPropertyValue("padding-top"))-Number.parseFloat(i.getPropertyValue("padding-bottom"))}return{width:r,height:a}}function xe(e,n,r){return e<n?n:e>r?r:e}function Cr(e){if(e===void 0)return 0;if(typeof e=="number")return e;const n=/^((\d+)?\.?\d+?)(ms|s)?$/,r=e.match(n);if(r){const[,a,,i="ms"]=r;return Number(a)*(i==="ms"?1:1e3)}return 0}const Rr=["transitionDuration","transitionTimingFunction"],zr=Object.assign(Object.assign({},vt.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ne=!1;const $r=M({name:"Carousel",props:zr,slots:Object,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:r}=ge(e),a=I(null),i=I(null),p=I([]),C={value:[]},y=g(()=>e.direction==="vertical"),R=g(()=>y.value?"height":"width"),h=g(()=>y.value?"bottom":"right"),x=g(()=>e.effect==="slide"),w=g(()=>e.loop&&e.slidesPerView===1&&x.value),$=g(()=>e.effect==="custom"),B=g(()=>!x.value||e.centeredSlides?1:e.slidesPerView),W=g(()=>$.value?1:e.slidesPerView),z=g(()=>B.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),k=I({width:0,height:0}),U=I(0),F=g(()=>{const{value:t}=p;if(!t.length)return[];U.value;const{value:s}=z;if(s)return t.map(b=>dt(b));const{value:o}=W,{value:c}=k,{value:d}=R;let l=c[d];if(o!=="auto"){const{spaceBetween:b}=e,D=l-(o-1)*b,ve=1/Math.max(1,o);l=D*ve}const m=Object.assign(Object.assign({},c),{[d]:l});return t.map(()=>m)}),j=g(()=>{const{value:t}=F;if(!t.length)return[];const{centeredSlides:s,spaceBetween:o}=e,{value:c}=R,{[c]:d}=k.value;let l=0;return t.map(({[c]:m})=>{let b=l;return s&&(b+=(m-d)/2),l+=m+o,b})}),Ze=I(!1),he=g(()=>{const{transitionStyle:t}=e;return t?tt(t,Rr):{}}),be=g(()=>$.value?0:Cr(he.value.transitionDuration)),We=g(()=>{const{value:t}=p;if(!t.length)return[];const s=!(z.value||W.value===1),o=m=>{if(s){const{value:b}=R;return{[b]:`${F.value[m][b]}px`}}};if($.value)return t.map((m,b)=>o(b));const{effect:c,spaceBetween:d}=e,{value:l}=h;return t.reduce((m,b,D)=>{const ve=Object.assign(Object.assign({},o(D)),{[`margin-${l}`]:`${d}px`});return m.push(ve),Ze.value&&(c==="fade"||c==="card")&&Object.assign(ve,he.value),m},[])}),N=g(()=>{const{value:t}=B,{length:s}=p.value;if(t!=="auto")return Math.max(s-t,0)+1;{const{value:o}=F,{length:c}=o;if(!c)return s;const{value:d}=j,{value:l}=R,m=k.value[l];let b=o[o.length-1][l],D=c;for(;D>1&&b<m;)D--,b+=d[D]-d[D-1];return xe(D+1,1,c)}}),we=g(()=>Sr(N.value,w.value)),Pt=Te(e.defaultIndex,w.value),_e=I(ut(Pt,N.value,w.value)),V=cn(dn(e,"currentIndex"),_e),E=g(()=>Te(V.value,w.value));function ee(t){var s,o;t=xe(t,0,N.value-1);const c=ut(t,N.value,w.value),{value:d}=V;c!==V.value&&(_e.value=c,(s=e["onUpdate:currentIndex"])===null||s===void 0||s.call(e,c,d),(o=e.onUpdateCurrentIndex)===null||o===void 0||o.call(e,c,d))}function ye(t=E.value){return _r(t,N.value,e.loop)}function Se(t=E.value){return yr(t,N.value,e.loop)}function Dt(t){const s=H(t);return s!==null&&ye()===s}function Tt(t){const s=H(t);return s!==null&&Se()===s}function Fe(t){return E.value===H(t)}function Nt(t){return V.value===t}function Ye(){return ye()===null}function Xe(){return Se()===null}let X=0;function Ce(t){const s=xe(Te(t,w.value),0,N.value);(t!==V.value||s!==E.value)&&ee(s)}function ie(){const t=ye();t!==null&&(X=-1,ee(t))}function te(){const t=Se();t!==null&&(X=1,ee(t))}let A=!1;function Et(){(!A||!w.value)&&ie()}function At(){(!A||!w.value)&&te()}let Y=0;const Re=I({});function le(t,s=0){Re.value=Object.assign({},he.value,{transform:y.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${s}ms`})}function ne(t=0){x.value?ze(E.value,t):Y!==0&&(!A&&t>0&&(A=!0),le(Y=0,t))}function ze(t,s){const o=He(t);o!==Y&&s>0&&(A=!0),Y=He(E.value),le(o,s)}function He(t){let s;return t>=N.value-1?s=Ke():s=j.value[t]||0,s}function Ke(){if(B.value==="auto"){const{value:t}=R,{[t]:s}=k.value,{value:o}=j,c=o[o.length-1];let d;if(c===void 0)d=s;else{const{value:l}=F;d=c+l[l.length-1][t]}return d-s}else{const{value:t}=j;return t[N.value-1]||0}}const re={currentIndexRef:V,to:Ce,prev:Et,next:At,isVertical:()=>y.value,isHorizontal:()=>!y.value,isPrev:Dt,isNext:Tt,isActive:Fe,isPrevDisabled:Ye,isNextDisabled:Xe,getSlideIndex:H,getSlideStyle:Mt,addSlide:Ot,removeSlide:Vt,onCarouselItemClick:Ut};dr(re);function Ot(t){t&&p.value.push(t)}function Vt(t){if(!t)return;const s=H(t);s!==-1&&p.value.splice(s,1)}function H(t){return typeof t=="number"?t:t?p.value.indexOf(t):-1}function Mt(t){const s=H(t);if(s!==-1){const o=[We.value[s]],c=re.isPrev(s),d=re.isNext(s);return c&&o.push(e.prevSlideStyle||""),d&&o.push(e.nextSlideStyle||""),xt(o)}}let $e=0,ke=0,L=0,Ie=0,ue=!1,Pe=!1;function Ut(t,s){let o=!A&&!ue&&!Pe;e.effect==="card"&&o&&!Fe(t)&&(Ce(t),o=!1),o||(s.preventDefault(),s.stopPropagation())}let ce=null;function de(){ce&&(clearInterval(ce),ce=null)}function K(){de(),!e.autoplay||we.value<2||(ce=window.setInterval(te,e.interval))}function qe(t){var s;if(Ne||!(!((s=i.value)===null||s===void 0)&&s.contains(gn(t))))return;Ne=!0,ue=!0,Pe=!1,Ie=Date.now(),de(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const o=ct(t)?t.touches[0]:t;y.value?ke=o.clientY:$e=o.clientX,e.touchable&&(se("touchmove",document,fe),se("touchend",document,q),se("touchcancel",document,q)),e.draggable&&(se("mousemove",document,fe),se("mouseup",document,q))}function fe(t){const{value:s}=y,{value:o}=R,c=ct(t)?t.touches[0]:t,d=s?c.clientY-ke:c.clientX-$e,l=k.value[o];L=xe(d,-l,l),t.cancelable&&t.preventDefault(),x.value&&le(Y-L,0)}function q(){const{value:t}=E;let s=t;if(!A&&L!==0&&x.value){const o=Y-L,c=[...j.value.slice(0,N.value-1),Ke()];let d=null;for(let l=0;l<c.length;l++){const m=Math.abs(c[l]-o);if(d!==null&&d<m)break;d=m,s=l}}if(s===t){const o=Date.now()-Ie,{value:c}=R,d=k.value[c];L>d/2||L/o>.4?ie():(L<-d/2||L/o<-.4)&&te()}s!==null&&s!==t?(Pe=!0,ee(s),nt(()=>{(!w.value||_e.value!==V.value)&&ne(be.value)})):ne(be.value),Je(),K()}function Je(){ue&&(Ne=!1),ue=!1,$e=0,ke=0,L=0,Ie=0,oe("touchmove",document,fe),oe("touchend",document,q),oe("touchcancel",document,q),oe("mousemove",document,fe),oe("mouseup",document,q)}function jt(){if(x.value&&A){const{value:t}=E;ze(t,0)}else K();x.value&&(Re.value.transitionDuration="0ms"),A=!1}function Lt(t){if(t.preventDefault(),A)return;let{deltaX:s,deltaY:o}=t;t.shiftKey&&!s&&(s=o);const c=-1,d=1,l=(s||o)>0?d:c;let m=0,b=0;y.value?b=l:m=l;const D=10;(b*o>=D||m*s>=D)&&(l===d&&!Xe()?te():l===c&&!Ye()&&ie())}function Bt(){k.value=dt(a.value,!0),K()}function Zt(){z.value&&U.value++}function Wt(){e.autoplay&&de()}function Ft(){e.autoplay&&K()}Ve(()=>{fn(K),requestAnimationFrame(()=>Ze.value=!0)}),Me(()=>{Je(),de()}),vn(()=>{const{value:t}=p,{value:s}=C,o=new Map,c=l=>o.has(l)?o.get(l):-1;let d=!1;for(let l=0;l<t.length;l++){const m=s.findIndex(b=>b.el===t[l]);m!==l&&(d=!0),o.set(t[l],m)}d&&t.sort((l,m)=>c(l)-c(m))}),ae(E,(t,s)=>{if(t===s){X=0;return}if(K(),x.value){if(w.value){const{value:o}=N;X===-1&&s===1&&t===o-2?t=0:X===1&&s===o-2&&t===1&&(t=o-1)}ze(t,be.value)}else ne();X=0},{immediate:!0}),ae([w,B],()=>void nt(()=>{ee(E.value)})),ae(j,()=>{x.value&&ne()},{deep:!0}),ae(x,t=>{t?ne():(A=!1,le(Y=0))});const Yt=g(()=>({onTouchstartPassive:e.touchable?qe:void 0,onMousedown:e.draggable?qe:void 0,onWheel:e.mousewheel?Lt:void 0})),Xt=g(()=>Object.assign(Object.assign({},tt(re,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:we.value,currentIndex:V.value})),Ht=g(()=>({total:we.value,currentIndex:V.value,to:re.to})),Kt={getCurrentIndex:()=>V.value,to:Ce,prev:ie,next:te},qt=vt("Carousel","-carousel",br,xn,e,n),Ge=g(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:s,dotColor:o,dotColorActive:c,dotColorFocus:d,dotLineWidth:l,dotLineWidthActive:m,arrowColor:b}}=qt.value;return{"--n-bezier":t,"--n-dot-color":o,"--n-dot-color-focus":d,"--n-dot-color-active":c,"--n-dot-size":s,"--n-dot-line-width":l,"--n-dot-line-width-active":m,"--n-arrow-color":b}}),J=r?pn("carousel",void 0,Ge,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:n,selfElRef:a,slidesElRef:i,slideVNodes:C,duplicatedable:w,userWantsControl:$,autoSlideSize:z,realIndex:E,slideStyles:We,translateStyle:Re,slidesControlListeners:Yt,handleTransitionEnd:jt,handleResize:Bt,handleSlideResize:Zt,handleMouseenter:Wt,handleMouseleave:Ft,isActive:Nt,arrowSlotProps:Xt,dotSlotProps:Ht},Kt),{cssVars:r?void 0:Ge,themeClass:J==null?void 0:J.themeClass,onRender:J==null?void 0:J.onRender})},render(){var e;const{mergedClsPrefix:n,showArrow:r,userWantsControl:a,slideStyles:i,dotType:p,dotPlacement:C,slidesControlListeners:y,transitionProps:R={},arrowSlotProps:h,dotSlotProps:x,$slots:{default:w,dots:$,arrow:B}}=this,W=w&&on(w())||[];let z=kr(W);return z.length||(z=W.map(k=>_(hr,null,{default:()=>ft(k)}))),this.duplicatedable&&(z=wr(z)),this.slideVNodes.value=z,this.autoSlideSize&&(z=z.map(k=>_(Qe,{onResize:this.handleSlideResize},{default:()=>k}))),(e=this.onRender)===null||e===void 0||e.call(this),_("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${n}-carousel`,this.direction==="vertical"&&`${n}-carousel--vertical`,this.showArrow&&`${n}-carousel--show-arrow`,`${n}-carousel--${C}`,`${n}-carousel--${this.direction}`,`${n}-carousel--${this.effect}`,a&&`${n}-carousel--usercontrol`],style:this.cssVars},y,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),_(Qe,{onResize:this.handleResize},{default:()=>_("div",{ref:"slidesElRef",class:`${n}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},a?z.map((k,U)=>_("div",{style:i[U],key:U},an(_(un,Object.assign({},R),{default:()=>k}),[[ln,this.isActive(U)]]))):z)}),this.showDots&&x.total>1&&et($,x,()=>[_(gr,{key:p+C,total:x.total,currentIndex:x.currentIndex,dotType:p,trigger:this.trigger,keyboard:this.keyboard})]),r&&et(B,h,()=>[_(xr,null)]))}});function kr(e){return e.reduce((n,r)=>(mr(r)&&n.push(r),n),[])}const Ir={class:"home-container animate__animated animate__pulse"},Pr=M({__name:"PageBanner",setup(e){const n=I(),{y:r}=hn();return ae(r,a=>{n.value.style.transform=`translateY(${-a/6}px)`}),(a,i)=>(S(),P("div",Ir,[i[0]||(i[0]=u("div",{class:"logo animate__animated animate__fadeInUp pointer-events-none"},[u("div",{class:"title mx-auto"},[u("div",{class:"text-9xl sm:text-100px md:text-120px lg:text-140px scale-x-115"},"TJUUS")]),u("div",{class:"describe"},[Ae("TianJinUniversity"),u("br"),Ae("UnitedServer")])],-1)),u("div",{class:"background",ref_key:"background",ref:n},null,512)]))}}),Dr=Z(Pr,[["__scopeId","data-v-5895cfd5"]]),Tr={},Nr={class:"bg flex justify-center items-center h-[100px] w-[85%] mt-5 rounded-3xl relative bg-cover bg-center hover:scale-105 transition-all"};function Er(e,n){return S(),P("div",Nr,n[0]||(n[0]=[u("div",{class:"tip-text absolute sm:text-3xl text-xl font-bold text-white pointer-events-none transition-all duration-300 ease-in-out"}," #网站正在施工中...... ",-1)]))}const Ar=Z(Tr,[["render",Er],["__scopeId","data-v-fa21c669"]]),Or={class:"mb-10"},Vr={class:"text-center font-semibold text-blue-400 dark:text-blue-300 text-xl sm:text-2xl md:text-3xl lg:text-4xl opacity-80"},Mr={class:"text-center italic relative text-lg sm:text-xl mt-[-15px] text-sky-700 dark:text-blue-200"},Ee=M({__name:"SectionTitle",props:{main:String,sub:String},setup(e){return(n,r)=>(S(),P("div",Or,[u("div",Vr,Q(e.main),1),u("div",Mr,Q(e.sub),1)]))}}),Ur={class:"card border border-solid border-zinc-200 rounded-lg shadow-lg border-opacity-20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-white bg-white transition-all duration-500 ease-in-out hover:scale-105 lg:w-4/5 max-w-[780px] box-border"},jr={class:"flex flex-col md:flex-row md:h-55 p-0"},Lr=["src"],Br={class:"text-xl font-bold mb-2"},Zr=M({__name:"InfoCard",props:{imageSrc:{type:String,required:!0},title:{type:String,required:!0},description:{type:String,required:!0},imageOnRight:{type:Boolean,default:!1}},setup(e){function n(a){return a.slice(0,30)+(a.length>30?"......":"")}const r=e;return(a,i)=>(S(),P("div",Ur,[u("div",jr,[u("div",{class:De(["w-full md:w-1/2",{"md:order-2":e.imageOnRight,"order-1":!e.imageOnRight}])},[u("img",{src:r.imageSrc,class:De(["w-full h-full object-cover",{"rounded-t-lg md:rounded-l-lg md:rounded-tr-none":!e.imageOnRight,"rounded-t-lg md:rounded-r-lg md:rounded-tl-none":e.imageOnRight}])},null,10,Lr)],2),u("div",{class:De(["w-full md:w-1/2 px-6 py-4 min-h-40 text-black dark:text-white",{"order-1":e.imageOnRight,"order-2":!e.imageOnRight}])},[u("h2",Br,Q(r.title),1),u("p",null,Q(n(r.description)),1)],2)])]))}}),Wr=[{imageSrc:"server/tianda1.png",title:"文本1",description:"这是文本1的描述"},{imageSrc:"server/tianda2.png",title:"文本2",description:"这是文本2的描述"},{imageSrc:"server/tianda2.png",title:"文本3",description:"这是文本3的描述"},{imageSrc:"server/tianda2.png",title:"文本4",description:"这是文本4的描述"},{imageSrc:"server/tianda2.png",title:"文本5",description:"这是文本5的描述"}],Fr=["eg/1.png","eg/2.png","eg/0.png","eg/5.png","eg/7.png","eg/8.png"],Yr=[{imageSrc:"building/eastDoor.png",title:"东大门",description:"北洋"},{imageSrc:"building/shiShi.png",title:"北洋广场",description:"实事求是"},{imageSrc:"building/胡.png",title:"求是亭",description:"求真务实"},{imageSrc:"building/水塔.png",title:"校史馆",description:"百卅天大"}],Be={server:Wr,carousel:Fr,building:Yr},Xr={class:"servers-container sm:w-85% box-border"},Hr={class:"grid place-items-center"},Kr=M({__name:"InfoCards",setup(e){const n=I(Be.server);return(r,a)=>(S(),P("div",Xr,[u("div",Hr,[(S(!0),P(me,null,Ue(n.value,(i,p)=>(S(),je(Zr,{key:p,imageSrc:i.imageSrc,title:i.title,description:i.description,imageOnRight:p%2===1},null,8,["imageSrc","title","description","imageOnRight"]))),128))])]))}}),qr=Z(Kr,[["__scopeId","data-v-93140b40"]]),Jr={class:"component p-4"},Gr={class:"flex justify-center items-center"},Qr={class:"text-2xl font-semibold mb-2 text-center mt-5 text-zinc-800 dark:text-blue-400"},es={class:"text-center text-sm dark:text-blue-300"},ts={__name:"FeaturedItem",props:{title:{type:String,required:!0},description:{type:String,required:!0},imageSrc:{type:String,required:!0}},setup(e){return(n,r)=>(S(),P("div",Jr,[u("div",Gr,[u("div",{class:"bg-cover w-full aspect-[1/0.55] rounded-lg hover:scale-105 transition-all duration-300 border-white dark:border-zinc-900",style:xt({backgroundImage:`url(${e.imageSrc})`})},null,4)]),u("h2",Qr,Q(e.title),1),u("p",es,Q(e.description),1)]))}},ns={class:"building-container"},rs={class:"grid",style:{gridTemplateColumns:"repeat(auto-fit, minmax(250px, 1fr))"}},ss=M({__name:"FeaturedItems",setup(e){const n=I(Be.building);return(r,a)=>(S(),P("div",ns,[u("div",rs,[(S(!0),P(me,null,Ue(n.value,(i,p)=>(S(),je(ts,{key:p,imageSrc:i.imageSrc,title:i.title,description:i.description},null,8,["imageSrc","title","description"]))),128))])]))}}),os=Z(ss,[["__scopeId","data-v-342f42e6"]]),as=["src"],is={__name:"Carousel",setup(e){const n=I(1),r=I(Be.carousel);function a(){n.value=window.innerWidth>768?3:1}return Ve(()=>{a(),window.addEventListener("resize",a)}),Me(()=>{window.removeEventListener("resize",a)}),(i,p)=>(S(),je(pt($r),{autoplay:"","slides-per-view":n.value,"space-between":20},{default:mn(()=>[(S(!0),P(me,null,Ue(r.value,(C,y)=>(S(),P("img",{key:y,class:"carousel-img",src:C},null,8,as))),128))]),_:1},8,["slides-per-view"]))}},ls=Z(is,[["__scopeId","data-v-b2593021"]]),us={},cs={class:"back-img relative sm:h-[500px] h-[300px] w-screen bg-fixed bg-[50%_80%] bg-auto"};function ds(e,n){return S(),P("div",cs,n[0]||(n[0]=[u("div",{class:"absolute inset-0 bg-opacity-70 z-[0.5]"},null,-1),u("div",{class:"text-white relative"},[u("div",{class:"z-[1] absolute overflow-hidden sm:h-[500px] w-screen h-[300px] p-[30px] pl-15 box-border flex flex-col items-start flex-wrap text-2xl gap-y-3.5"},[u("h1",null,"TJUUS"),u("h2",null,"是一个"),u("h2",null,"人很多"),u("h2",null,"的"),u("h2",null,"社团")])],-1)]))}const fs=Z(us,[["render",ds],["__scopeId","data-v-7bcb5739"]]),vs="/TJUUS/icon/bili.png",xs={},ps={class:"follow-container"};function gs(e,n){return S(),P("div",ps,n[0]||(n[0]=[u("div",{class:"overlay"},[u("h1",null,"关注我们!!!!!"),u("p",null,[u("a",{href:"https://space.bilibili.com/1343371808",target:"_blank",class:"text-white flex items-center justify-center decoration-none"},[u("img",{src:vs,alt:"bilibili Logo",class:"h-7 mr-2"}),Ae(" bilibili ")])])],-1)]))}const ms=Z(xs,[["render",gs],["__scopeId","data-v-adb5bdbb"]]),hs={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-[85%] py-8"},bs={class:"grid sc box-border justify-center items-center sm:mx-7 mx-9"},ws={class:"grid-cols-1"},_s={class:"h-auto w-0 justify-self-start creeper"},ys={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-80% py-8"},Ss={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-5 w-80% py-8"},Cs=M({__name:"Home",setup(e){return(n,r)=>(S(),P(me,null,[T(Dr),u("section",hs,[T(Ar,{class:"developing"})]),T(pt(wn),{dashed:!0}),u("section",bs,[u("div",ws,[T(qr,{class:"row lg:w-80%"})]),u("div",_s,[T(bn,{class:"sm:h-[350px] sm:w-[300px] md:h-[400px] md:w-[400px] lg:h-[550px] lg:w-[550px] h-[260px] w-[250px]"})])]),u("section",ys,[T(Ee,{class:"row my",main:"我们是",sub:"TJUUS"})]),T(fs),u("section",Ss,[T(Ee,{class:"row my",main:"建设成果",sub:"探索Minecraft的无限可能"}),T(os,{class:"row"}),T(Ee,{class:"row my-5",main:"我们的伙伴",sub:"联合"}),T(ls,{class:"row my-5"})]),T(ms,{class:"mt"})],64))}}),ks=Z(Cs,[["__scopeId","data-v-4f6d9288"]]);export{ks as default};
