import{u as qt,t as Me,a as Qt,i as en,c as tn,p as nn,d as A,h as R,b as he,e as rn,r as N,o as sn,f as g,g as be,j as je,k as on,l as v,m as x,n as B,q as vt,s as an,V as et,v as tt,w as ln,x as un,T as cn,y as nt,z as dn,A as fn,B as pn,C as vn,D as Z,E as xt,F as xn,G as mn,H as ie,I as rt,J as le,K as gn,L as mt,M as T,N as c,O as Ve,P,_ as Y,Q as te,R as hn,S as De,U as Ue,W as Le,X as Be,Y as bn,Z as Oe,$ as wn,a0 as E}from"./index-CELJtENO.js";import{u as _n,a as yn,b as Sn,c as Cn,S as Rn,P as zn,W as kn,G as Pn,A as $n,d as st,g as In}from"./index-Eqpng4bS.js";import{N as Tn}from"./Divider-BIsDRTCW.js";function Dn(e){return qt(Me(e).toLowerCase())}function Nn(e,n,r,o){for(var i=-1,l=e==null?0:e.length;++i<l;)r=n(r,e[i],i,e);return r}function En(e){return function(n){return e==null?void 0:e[n]}}var An={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},Vn=En(An),On=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,Mn="\\u0300-\\u036f",jn="\\ufe20-\\ufe2f",Un="\\u20d0-\\u20ff",Ln=Mn+jn+Un,Bn="["+Ln+"]",Wn=RegExp(Bn,"g");function Fn(e){return e=Me(e),e&&e.replace(On,Vn).replace(Wn,"")}var Yn=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function Xn(e){return e.match(Yn)||[]}var Zn=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function Hn(e){return Zn.test(e)}var gt="\\ud800-\\udfff",Kn="\\u0300-\\u036f",Jn="\\ufe20-\\ufe2f",Gn="\\u20d0-\\u20ff",qn=Kn+Jn+Gn,ht="\\u2700-\\u27bf",bt="a-z\\xdf-\\xf6\\xf8-\\xff",Qn="\\xac\\xb1\\xd7\\xf7",er="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",tr="\\u2000-\\u206f",nr=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",wt="A-Z\\xc0-\\xd6\\xd8-\\xde",rr="\\ufe0e\\ufe0f",_t=Qn+er+tr+nr,yt="['’]",ot="["+_t+"]",sr="["+qn+"]",St="\\d+",or="["+ht+"]",Ct="["+bt+"]",Rt="[^"+gt+_t+St+ht+bt+wt+"]",ar="\\ud83c[\\udffb-\\udfff]",ir="(?:"+sr+"|"+ar+")",lr="[^"+gt+"]",zt="(?:\\ud83c[\\udde6-\\uddff]){2}",kt="[\\ud800-\\udbff][\\udc00-\\udfff]",ee="["+wt+"]",ur="\\u200d",at="(?:"+Ct+"|"+Rt+")",cr="(?:"+ee+"|"+Rt+")",it="(?:"+yt+"(?:d|ll|m|re|s|t|ve))?",lt="(?:"+yt+"(?:D|LL|M|RE|S|T|VE))?",Pt=ir+"?",$t="["+rr+"]?",dr="(?:"+ur+"(?:"+[lr,zt,kt].join("|")+")"+$t+Pt+")*",fr="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",pr="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",vr=$t+Pt+dr,xr="(?:"+[or,zt,kt].join("|")+")"+vr,mr=RegExp([ee+"?"+Ct+"+"+it+"(?="+[ot,ee,"$"].join("|")+")",cr+"+"+lt+"(?="+[ot,ee+at,"$"].join("|")+")",ee+"?"+at+"+"+it,ee+"+"+lt,pr,fr,St,xr].join("|"),"g");function gr(e){return e.match(mr)||[]}function hr(e,n,r){return e=Me(e),n=n,n===void 0?Hn(e)?gr(e):Xn(e):e.match(n)||[]}var br="['’]",wr=RegExp(br,"g");function _r(e){return function(n){return Nn(hr(Fn(n).replace(wr,"")),e,"")}}var ut=_r(function(e,n,r){return n=n.toLowerCase(),e+(r?Dn(n):n)});const It=tn("n-carousel-methods");function yr(e){nn(It,e)}function We(e="unknown",n="component"){const r=en(It);return r||Qt(e,`\`${n}\` must be placed inside \`n-carousel\`.`),r}function Sr(){return R("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},R("g",{fill:"none"},R("path",{d:"M10.26 3.2a.75.75 0 0 1 .04 1.06L6.773 8l3.527 3.74a.75.75 0 1 1-1.1 1.02l-4-4.25a.75.75 0 0 1 0-1.02l4-4.25a.75.75 0 0 1 1.06-.04z",fill:"currentColor"})))}function Cr(){return R("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},R("g",{fill:"none"},R("path",{d:"M5.74 3.2a.75.75 0 0 0-.04 1.06L9.227 8L5.7 11.74a.75.75 0 1 0 1.1 1.02l4-4.25a.75.75 0 0 0 0-1.02l-4-4.25a.75.75 0 0 0-1.06-.04z",fill:"currentColor"})))}const Rr=A({name:"CarouselArrow",setup(e){const{mergedClsPrefixRef:n}=he(e),{isVertical:r,isPrevDisabled:o,isNextDisabled:i,prev:l,next:z}=We();return{mergedClsPrefix:n,isVertical:r,isPrevDisabled:o,isNextDisabled:i,prev:l,next:z}},render(){const{mergedClsPrefix:e}=this;return R("div",{class:`${e}-carousel__arrow-group`},R("div",{class:[`${e}-carousel__arrow`,this.isPrevDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.prev},Sr()),R("div",{class:[`${e}-carousel__arrow`,this.isNextDisabled()&&`${e}-carousel__arrow--disabled`],role:"button",onClick:this.next},Cr()))}}),zr={total:{type:Number,default:0},currentIndex:{type:Number,default:0},dotType:{type:String,default:"dot"},trigger:{type:String,default:"click"},keyboard:Boolean},kr=A({name:"CarouselDots",props:zr,setup(e){const{mergedClsPrefixRef:n}=he(e),r=N([]),o=We();function i(m,d){switch(m.key){case"Enter":case" ":m.preventDefault(),o.to(d);return}e.keyboard&&C(m)}function l(m){e.trigger==="hover"&&o.to(m)}function z(m){e.trigger==="click"&&o.to(m)}function C(m){var d;if(m.shiftKey||m.altKey||m.ctrlKey||m.metaKey)return;const w=(d=document.activeElement)===null||d===void 0?void 0:d.nodeName.toLowerCase();if(w==="input"||w==="textarea")return;const{code:k}=m,M=k==="PageUp"||k==="ArrowUp",D=k==="PageDown"||k==="ArrowDown",b=k==="PageUp"||k==="ArrowRight",y=k==="PageDown"||k==="ArrowLeft",$=o.isVertical(),V=$?M:b,I=$?D:y;!V&&!I||(m.preventDefault(),V&&!o.isNextDisabled()?(o.next(),_(o.currentIndexRef.value)):I&&!o.isPrevDisabled()&&(o.prev(),_(o.currentIndexRef.value)))}function _(m){var d;(d=r.value[m])===null||d===void 0||d.focus()}return sn(()=>r.value.length=0),{mergedClsPrefix:n,dotEls:r,handleKeydown:i,handleMouseenter:l,handleClick:z}},render(){const{mergedClsPrefix:e,dotEls:n}=this;return R("div",{class:[`${e}-carousel__dots`,`${e}-carousel__dots--${this.dotType}`],role:"tablist"},rn(this.total,r=>{const o=r===this.currentIndex;return R("div",{"aria-selected":o,ref:i=>n.push(i),role:"button",tabindex:"0",class:[`${e}-carousel__dot`,o&&`${e}-carousel__dot--active`],key:r,onClick:()=>{this.handleClick(r)},onMouseenter:()=>{this.handleMouseenter(r)},onKeydown:i=>{this.handleKeydown(i,r)}})}))}}),ge="CarouselItem";function Pr(e){var n;return((n=e.type)===null||n===void 0?void 0:n.name)===ge}const $r=A({name:ge,setup(e){const{mergedClsPrefixRef:n}=he(e),r=We(ut(ge),`n-${ut(ge)}`),o=N(),i=g(()=>{const{value:d}=o;return d?r.getSlideIndex(d):-1}),l=g(()=>r.isPrev(i.value)),z=g(()=>r.isNext(i.value)),C=g(()=>r.isActive(i.value)),_=g(()=>r.getSlideStyle(i.value));be(()=>{r.addSlide(o.value)}),je(()=>{r.removeSlide(o.value)});function m(d){const{value:w}=i;w!==void 0&&(r==null||r.onCarouselItemClick(w,d))}return{mergedClsPrefix:n,selfElRef:o,isPrev:l,isNext:z,isActive:C,index:i,style:_,handleClick:m}},render(){var e;const{$slots:n,mergedClsPrefix:r,isPrev:o,isNext:i,isActive:l,index:z,style:C}=this,_=[`${r}-carousel__slide`,{[`${r}-carousel__slide--current`]:l,[`${r}-carousel__slide--prev`]:o,[`${r}-carousel__slide--next`]:i}];return R("div",{ref:"selfElRef",class:_,role:"option",tabindex:"-1","data-index":z,"aria-hidden":!l,style:C,onClickCapture:this.handleClick},(e=n.default)===null||e===void 0?void 0:e.call(n,{isPrev:o,isNext:i,isActive:l,index:z}))}}),Ir=on("carousel",`
 position: relative;
 width: 100%;
 height: 100%;
 touch-action: pan-y;
 overflow: hidden;
`,[v("slides",`
 display: flex;
 width: 100%;
 height: 100%;
 transition-timing-function: var(--n-bezier);
 transition-property: transform;
 `,[v("slide",`
 flex-shrink: 0;
 position: relative;
 width: 100%;
 height: 100%;
 outline: none;
 overflow: hidden;
 `,[B("> img",`
 display: block;
 `)])]),v("dots",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `,[x("dot",[v("dot",`
 height: var(--n-dot-size);
 width: var(--n-dot-size);
 background-color: var(--n-dot-color);
 border-radius: 50%;
 cursor: pointer;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[B("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),x("active",`
 background-color: var(--n-dot-color-active);
 `)])]),x("line",[v("dot",`
 border-radius: 9999px;
 width: var(--n-dot-line-width);
 height: 4px;
 background-color: var(--n-dot-color);
 cursor: pointer;
 transition:
 width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[B("&:focus",`
 background-color: var(--n-dot-color-focus);
 `),x("active",`
 width: var(--n-dot-line-width-active);
 background-color: var(--n-dot-color-active);
 `)])])]),v("arrow",`
 transition: background-color .3s var(--n-bezier);
 cursor: pointer;
 height: 28px;
 width: 28px;
 display: flex;
 align-items: center;
 justify-content: center;
 background-color: rgba(255, 255, 255, .2);
 color: var(--n-arrow-color);
 border-radius: 8px;
 user-select: none;
 -webkit-user-select: none;
 font-size: 18px;
 `,[B("svg",`
 height: 1em;
 width: 1em;
 `),B("&:hover",`
 background-color: rgba(255, 255, 255, .3);
 `)]),x("vertical",`
 touch-action: pan-x;
 `,[v("slides",`
 flex-direction: column;
 `),x("fade",[v("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%);
 `)]),x("card",[v("slide",`
 top: 50%;
 left: unset;
 transform: translateY(-50%) translateZ(-400px);
 `,[x("current",`
 transform: translateY(-50%) translateZ(0);
 `),x("prev",`
 transform: translateY(-100%) translateZ(-200px);
 `),x("next",`
 transform: translateY(0%) translateZ(-200px);
 `)])])]),x("usercontrol",[v("slides",[B(">",[B("div",`
 position: absolute;
 top: 50%;
 left: 50%;
 width: 100%;
 height: 100%;
 transform: translate(-50%, -50%);
 `)])])]),x("left",[v("dots",`
 transform: translateY(-50%);
 top: 50%;
 left: 12px;
 flex-direction: column;
 `,[x("line",[v("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[x("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),v("dot",`
 margin: 4px 0;
 `)]),v("arrow-group",`
 position: absolute;
 display: flex;
 flex-wrap: nowrap;
 `),x("vertical",[v("arrow",`
 transform: rotate(90deg);
 `)]),x("show-arrow",[x("bottom",[v("dots",`
 transform: translateX(0);
 bottom: 18px;
 left: 18px;
 `)]),x("top",[v("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),x("left",[v("dots",`
 transform: translateX(0);
 top: 18px;
 left: 18px;
 `)]),x("right",[v("dots",`
 transform: translateX(0);
 top: 18px;
 right: 18px;
 `)])]),x("left",[v("arrow-group",`
 bottom: 12px;
 left: 12px;
 flex-direction: column;
 `,[B("> *:first-child",`
 margin-bottom: 12px;
 `)])]),x("right",[v("dots",`
 transform: translateY(-50%);
 top: 50%;
 right: 12px;
 flex-direction: column;
 `,[x("line",[v("dot",`
 width: 4px;
 height: var(--n-dot-line-width);
 margin: 4px 0;
 transition:
 height .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 outline: none;
 `,[x("active",`
 height: var(--n-dot-line-width-active);
 `)])])]),v("dot",`
 margin: 4px 0;
 `),v("arrow-group",`
 bottom: 12px;
 right: 12px;
 flex-direction: column;
 `,[B("> *:first-child",`
 margin-bottom: 12px;
 `)])]),x("top",[v("dots",`
 transform: translateX(-50%);
 top: 12px;
 left: 50%;
 `,[x("line",[v("dot",`
 margin: 0 4px;
 `)])]),v("dot",`
 margin: 0 4px;
 `),v("arrow-group",`
 top: 12px;
 right: 12px;
 `,[B("> *:first-child",`
 margin-right: 12px;
 `)])]),x("bottom",[v("dots",`
 transform: translateX(-50%);
 bottom: 12px;
 left: 50%;
 `,[x("line",[v("dot",`
 margin: 0 4px;
 `)])]),v("dot",`
 margin: 0 4px;
 `),v("arrow-group",`
 bottom: 12px;
 right: 12px;
 `,[B("> *:first-child",`
 margin-right: 12px;
 `)])]),x("fade",[v("slide",`
 position: absolute;
 opacity: 0;
 transition-property: opacity;
 pointer-events: none;
 `,[x("current",`
 opacity: 1;
 pointer-events: auto;
 `)])]),x("card",[v("slides",`
 perspective: 1000px;
 `),v("slide",`
 position: absolute;
 left: 50%;
 opacity: 0;
 transform: translateX(-50%) translateZ(-400px);
 transition-property: opacity, transform;
 `,[x("current",`
 opacity: 1;
 transform: translateX(-50%) translateZ(0);
 z-index: 1;
 `),x("prev",`
 opacity: 0.4;
 transform: translateX(-100%) translateZ(-200px);
 `),x("next",`
 opacity: 0.4;
 transform: translateX(0%) translateZ(-200px);
 `)])])]);function Tr(e){const{length:n}=e;return n>1&&(e.push(ct(e[0],0,"append")),e.unshift(ct(e[n-1],n-1,"prepend"))),e}function ct(e,n,r){return vt(e,{key:`carousel-item-duplicate-${n}-${r}`})}function dt(e,n,r){return n===1?0:r?e===0?n-3:e===n-1?0:e-1:e}function Ne(e,n){return n?e+1:e}function Dr(e,n,r){return e<0?null:e===0?r?n-1:null:e-1}function Nr(e,n,r){return e>n-1?null:e===n-1?r?0:null:e+1}function Er(e,n){return n&&e>3?e-2:e}function ft(e){return window.TouchEvent&&e instanceof window.TouchEvent}function pt(e,n){let{offsetWidth:r,offsetHeight:o}=e;if(n){const i=getComputedStyle(e);r=r-Number.parseFloat(i.getPropertyValue("padding-left"))-Number.parseFloat(i.getPropertyValue("padding-right")),o=o-Number.parseFloat(i.getPropertyValue("padding-top"))-Number.parseFloat(i.getPropertyValue("padding-bottom"))}return{width:r,height:o}}function me(e,n,r){return e<n?n:e>r?r:e}function Ar(e){if(e===void 0)return 0;if(typeof e=="number")return e;const n=/^((\d+)?\.?\d+?)(ms|s)?$/,r=e.match(n);if(r){const[,o,,i="ms"]=r;return Number(o)*(i==="ms"?1:1e3)}return 0}const Vr=["transitionDuration","transitionTimingFunction"],Or=Object.assign(Object.assign({},xt.props),{defaultIndex:{type:Number,default:0},currentIndex:Number,showArrow:Boolean,dotType:{type:String,default:"dot"},dotPlacement:{type:String,default:"bottom"},slidesPerView:{type:[Number,String],default:1},spaceBetween:{type:Number,default:0},centeredSlides:Boolean,direction:{type:String,default:"horizontal"},autoplay:Boolean,interval:{type:Number,default:5e3},loop:{type:Boolean,default:!0},effect:{type:String,default:"slide"},showDots:{type:Boolean,default:!0},trigger:{type:String,default:"click"},transitionStyle:{type:Object,default:()=>({transitionDuration:"300ms"})},transitionProps:Object,draggable:Boolean,prevSlideStyle:[Object,String],nextSlideStyle:[Object,String],touchable:{type:Boolean,default:!0},mousewheel:Boolean,keyboard:Boolean,"onUpdate:currentIndex":Function,onUpdateCurrentIndex:Function});let Ee=!1;const Mr=A({name:"Carousel",props:Or,slots:Object,setup(e){const{mergedClsPrefixRef:n,inlineThemeDisabled:r}=he(e),o=N(null),i=N(null),l=N([]),z={value:[]},C=g(()=>e.direction==="vertical"),_=g(()=>C.value?"height":"width"),m=g(()=>C.value?"bottom":"right"),d=g(()=>e.effect==="slide"),w=g(()=>e.loop&&e.slidesPerView===1&&d.value),k=g(()=>e.effect==="custom"),M=g(()=>!d.value||e.centeredSlides?1:e.slidesPerView),D=g(()=>k.value?1:e.slidesPerView),b=g(()=>M.value==="auto"||e.slidesPerView==="auto"&&e.centeredSlides),y=N({width:0,height:0}),$=N(0),V=g(()=>{const{value:t}=l;if(!t.length)return[];$.value;const{value:s}=b;if(s)return t.map(S=>pt(S));const{value:a}=D,{value:f}=y,{value:p}=_;let u=f[p];if(a!=="auto"){const{spaceBetween:S}=e,O=u-(a-1)*S,xe=1/Math.max(1,a);u=O*xe}const h=Object.assign(Object.assign({},f),{[p]:u});return t.map(()=>h)}),I=g(()=>{const{value:t}=V;if(!t.length)return[];const{centeredSlides:s,spaceBetween:a}=e,{value:f}=_,{[f]:p}=y.value;let u=0;return t.map(({[f]:h})=>{let S=u;return s&&(S+=(h-p)/2),u+=h+a,S})}),ne=N(!1),H=g(()=>{const{transitionStyle:t}=e;return t?nt(t,Vr):{}}),we=g(()=>k.value?0:Ar(H.value.transitionDuration)),Ye=g(()=>{const{value:t}=l;if(!t.length)return[];const s=!(b.value||D.value===1),a=h=>{if(s){const{value:S}=_;return{[S]:`${V.value[h][S]}px`}}};if(k.value)return t.map((h,S)=>a(S));const{effect:f,spaceBetween:p}=e,{value:u}=m;return t.reduce((h,S,O)=>{const xe=Object.assign(Object.assign({},a(O)),{[`margin-${u}`]:`${p}px`});return h.push(xe),ne.value&&(f==="fade"||f==="card")&&Object.assign(xe,H.value),h},[])}),j=g(()=>{const{value:t}=M,{length:s}=l.value;if(t!=="auto")return Math.max(s-t,0)+1;{const{value:a}=V,{length:f}=a;if(!f)return s;const{value:p}=I,{value:u}=_,h=y.value[u];let S=a[a.length-1][u],O=f;for(;O>1&&S<h;)O--,S+=p[O]-p[O-1];return me(O+1,1,f)}}),_e=g(()=>Er(j.value,w.value)),Tt=Ne(e.defaultIndex,w.value),ye=N(dt(Tt,j.value,w.value)),W=dn(fn(e,"currentIndex"),ye),U=g(()=>Ne(W.value,w.value));function re(t){var s,a;t=me(t,0,j.value-1);const f=dt(t,j.value,w.value),{value:p}=W;f!==W.value&&(ye.value=f,(s=e["onUpdate:currentIndex"])===null||s===void 0||s.call(e,f,p),(a=e.onUpdateCurrentIndex)===null||a===void 0||a.call(e,f,p))}function Se(t=U.value){return Dr(t,j.value,e.loop)}function Ce(t=U.value){return Nr(t,j.value,e.loop)}function Dt(t){const s=J(t);return s!==null&&Se()===s}function Nt(t){const s=J(t);return s!==null&&Ce()===s}function Xe(t){return U.value===J(t)}function Et(t){return W.value===t}function Ze(){return Se()===null}function He(){return Ce()===null}let K=0;function Re(t){const s=me(Ne(t,w.value),0,j.value);(t!==W.value||s!==U.value)&&re(s)}function ue(){const t=Se();t!==null&&(K=-1,re(t))}function se(){const t=Ce();t!==null&&(K=1,re(t))}let L=!1;function At(){(!L||!w.value)&&ue()}function Vt(){(!L||!w.value)&&se()}let X=0;const ze=N({});function ce(t,s=0){ze.value=Object.assign({},H.value,{transform:C.value?`translateY(${-t}px)`:`translateX(${-t}px)`,transitionDuration:`${s}ms`})}function oe(t=0){d.value?ke(U.value,t):X!==0&&(!L&&t>0&&(L=!0),ce(X=0,t))}function ke(t,s){const a=Ke(t);a!==X&&s>0&&(L=!0),X=Ke(U.value),ce(a,s)}function Ke(t){let s;return t>=j.value-1?s=Je():s=I.value[t]||0,s}function Je(){if(M.value==="auto"){const{value:t}=_,{[t]:s}=y.value,{value:a}=I,f=a[a.length-1];let p;if(f===void 0)p=s;else{const{value:u}=V;p=f+u[u.length-1][t]}return p-s}else{const{value:t}=I;return t[j.value-1]||0}}const ae={currentIndexRef:W,to:Re,prev:At,next:Vt,isVertical:()=>C.value,isHorizontal:()=>!C.value,isPrev:Dt,isNext:Nt,isActive:Xe,isPrevDisabled:Ze,isNextDisabled:He,getSlideIndex:J,getSlideStyle:jt,addSlide:Ot,removeSlide:Mt,onCarouselItemClick:Ut};yr(ae);function Ot(t){t&&l.value.push(t)}function Mt(t){if(!t)return;const s=J(t);s!==-1&&l.value.splice(s,1)}function J(t){return typeof t=="number"?t:t?l.value.indexOf(t):-1}function jt(t){const s=J(t);if(s!==-1){const a=[Ye.value[s]],f=ae.isPrev(s),p=ae.isNext(s);return f&&a.push(e.prevSlideStyle||""),p&&a.push(e.nextSlideStyle||""),mt(a)}}let Pe=0,$e=0,F=0,Ie=0,de=!1,Te=!1;function Ut(t,s){let a=!L&&!de&&!Te;e.effect==="card"&&a&&!Xe(t)&&(Re(t),a=!1),a||(s.preventDefault(),s.stopPropagation())}let fe=null;function pe(){fe&&(clearInterval(fe),fe=null)}function G(){pe(),!e.autoplay||_e.value<2||(fe=window.setInterval(se,e.interval))}function Ge(t){var s;if(Ee||!(!((s=i.value)===null||s===void 0)&&s.contains(mn(t))))return;Ee=!0,de=!0,Te=!1,Ie=Date.now(),pe(),t.type!=="touchstart"&&!t.target.isContentEditable&&t.preventDefault();const a=ft(t)?t.touches[0]:t;C.value?$e=a.clientY:Pe=a.clientX,e.touchable&&(ie("touchmove",document,ve),ie("touchend",document,q),ie("touchcancel",document,q)),e.draggable&&(ie("mousemove",document,ve),ie("mouseup",document,q))}function ve(t){const{value:s}=C,{value:a}=_,f=ft(t)?t.touches[0]:t,p=s?f.clientY-$e:f.clientX-Pe,u=y.value[a];F=me(p,-u,u),t.cancelable&&t.preventDefault(),d.value&&ce(X-F,0)}function q(){const{value:t}=U;let s=t;if(!L&&F!==0&&d.value){const a=X-F,f=[...I.value.slice(0,j.value-1),Je()];let p=null;for(let u=0;u<f.length;u++){const h=Math.abs(f[u]-a);if(p!==null&&p<h)break;p=h,s=u}}if(s===t){const a=Date.now()-Ie,{value:f}=_,p=y.value[f];F>p/2||F/a>.4?ue():(F<-p/2||F/a<-.4)&&se()}s!==null&&s!==t?(Te=!0,re(s),rt(()=>{(!w.value||ye.value!==W.value)&&oe(we.value)})):oe(we.value),qe(),G()}function qe(){de&&(Ee=!1),de=!1,Pe=0,$e=0,F=0,Ie=0,le("touchmove",document,ve),le("touchend",document,q),le("touchcancel",document,q),le("mousemove",document,ve),le("mouseup",document,q)}function Lt(){if(d.value&&L){const{value:t}=U;ke(t,0)}else G();d.value&&(ze.value.transitionDuration="0ms"),L=!1}function Bt(t){if(t.preventDefault(),L)return;let{deltaX:s,deltaY:a}=t;t.shiftKey&&!s&&(s=a);const f=-1,p=1,u=(s||a)>0?p:f;let h=0,S=0;C.value?S=u:h=u;const O=10;(S*a>=O||h*s>=O)&&(u===p&&!He()?se():u===f&&!Ze()&&ue())}function Wt(){y.value=pt(o.value,!0),G()}function Ft(){b.value&&$.value++}function Yt(){e.autoplay&&pe()}function Xt(){e.autoplay&&G()}be(()=>{pn(G),requestAnimationFrame(()=>ne.value=!0)}),je(()=>{qe(),pe()}),vn(()=>{const{value:t}=l,{value:s}=z,a=new Map,f=u=>a.has(u)?a.get(u):-1;let p=!1;for(let u=0;u<t.length;u++){const h=s.findIndex(S=>S.el===t[u]);h!==u&&(p=!0),a.set(t[u],h)}p&&t.sort((u,h)=>f(u)-f(h))}),Z(U,(t,s)=>{if(t===s){K=0;return}if(G(),d.value){if(w.value){const{value:a}=j;K===-1&&s===1&&t===a-2?t=0:K===1&&s===a-2&&t===1&&(t=a-1)}ke(t,we.value)}else oe();K=0},{immediate:!0}),Z([w,M],()=>void rt(()=>{re(U.value)})),Z(I,()=>{d.value&&oe()},{deep:!0}),Z(d,t=>{t?oe():(L=!1,ce(X=0))});const Zt=g(()=>({onTouchstartPassive:e.touchable?Ge:void 0,onMousedown:e.draggable?Ge:void 0,onWheel:e.mousewheel?Bt:void 0})),Ht=g(()=>Object.assign(Object.assign({},nt(ae,["to","prev","next","isPrevDisabled","isNextDisabled"])),{total:_e.value,currentIndex:W.value})),Kt=g(()=>({total:_e.value,currentIndex:W.value,to:ae.to})),Jt={getCurrentIndex:()=>W.value,to:Re,prev:ue,next:se},Gt=xt("Carousel","-carousel",Ir,gn,e,n),Qe=g(()=>{const{common:{cubicBezierEaseInOut:t},self:{dotSize:s,dotColor:a,dotColorActive:f,dotColorFocus:p,dotLineWidth:u,dotLineWidthActive:h,arrowColor:S}}=Gt.value;return{"--n-bezier":t,"--n-dot-color":a,"--n-dot-color-focus":p,"--n-dot-color-active":f,"--n-dot-size":s,"--n-dot-line-width":u,"--n-dot-line-width-active":h,"--n-arrow-color":S}}),Q=r?xn("carousel",void 0,Qe,e):void 0;return Object.assign(Object.assign({mergedClsPrefix:n,selfElRef:o,slidesElRef:i,slideVNodes:z,duplicatedable:w,userWantsControl:k,autoSlideSize:b,realIndex:U,slideStyles:Ye,translateStyle:ze,slidesControlListeners:Zt,handleTransitionEnd:Lt,handleResize:Wt,handleSlideResize:Ft,handleMouseenter:Yt,handleMouseleave:Xt,isActive:Et,arrowSlotProps:Ht,dotSlotProps:Kt},Jt),{cssVars:r?void 0:Qe,themeClass:Q==null?void 0:Q.themeClass,onRender:Q==null?void 0:Q.onRender})},render(){var e;const{mergedClsPrefix:n,showArrow:r,userWantsControl:o,slideStyles:i,dotType:l,dotPlacement:z,slidesControlListeners:C,transitionProps:_={},arrowSlotProps:m,dotSlotProps:d,$slots:{default:w,dots:k,arrow:M}}=this,D=w&&an(w())||[];let b=jr(D);return b.length||(b=D.map(y=>R($r,null,{default:()=>vt(y)}))),this.duplicatedable&&(b=Tr(b)),this.slideVNodes.value=b,this.autoSlideSize&&(b=b.map(y=>R(et,{onResize:this.handleSlideResize},{default:()=>y}))),(e=this.onRender)===null||e===void 0||e.call(this),R("div",Object.assign({ref:"selfElRef",class:[this.themeClass,`${n}-carousel`,this.direction==="vertical"&&`${n}-carousel--vertical`,this.showArrow&&`${n}-carousel--show-arrow`,`${n}-carousel--${z}`,`${n}-carousel--${this.direction}`,`${n}-carousel--${this.effect}`,o&&`${n}-carousel--usercontrol`],style:this.cssVars},C,{onMouseenter:this.handleMouseenter,onMouseleave:this.handleMouseleave}),R(et,{onResize:this.handleResize},{default:()=>R("div",{ref:"slidesElRef",class:`${n}-carousel__slides`,role:"listbox",style:this.translateStyle,onTransitionend:this.handleTransitionEnd},o?b.map((y,$)=>R("div",{style:i[$],key:$},ln(R(cn,Object.assign({},_),{default:()=>y}),[[un,this.isActive($)]]))):b)}),this.showDots&&d.total>1&&tt(k,d,()=>[R(kr,{key:l+z,total:d.total,currentIndex:d.currentIndex,dotType:l,trigger:this.trigger,keyboard:this.keyboard})]),r&&tt(M,m,()=>[R(Rr,null)]))}});function jr(e){return e.reduce((n,r)=>(Pr(r)&&n.push(r),n),[])}const Ur={class:"home-container animate__animated animate__pulse"},Lr=A({__name:"PageBanner",setup(e){const n=N(),{y:r}=_n();return Z(r,o=>{n.value.style.transform=`translateY(${-o/6}px)`}),(o,i)=>(P(),T("div",Ur,[i[0]||(i[0]=c("div",{class:"logo animate__animated animate__fadeInUp pointer-events-none"},[c("div",{class:"title mx-auto"},[c("div",{class:"text-9xl sm:text-100px md:text-120px lg:text-140px scale-x-115"},"TJUUS")]),c("div",{class:"describe"},[Ve("TianJinUniversity"),c("br"),Ve("UnitedServer")])],-1)),c("div",{class:"background",ref_key:"background",ref:n},null,512)]))}}),Br=Y(Lr,[["__scopeId","data-v-5895cfd5"]]),Wr={},Fr={class:"bg flex justify-center items-center h-[100px] w-[85%] mt-5 rounded-3xl relative bg-cover bg-center hover:scale-105 transition-all"};function Yr(e,n){return P(),T("div",Fr,n[0]||(n[0]=[c("div",{class:"tip-text absolute sm:text-3xl text-xl font-bold text-white pointer-events-none transition-all duration-300 ease-in-out"}," #网站正在施工中...... ",-1)]))}const Xr=Y(Wr,[["render",Yr],["__scopeId","data-v-fa21c669"]]),Zr={class:"mb-10"},Hr={class:"text-center font-semibold text-blue-400 dark:text-blue-300 text-xl sm:text-2xl md:text-3xl lg:text-4xl opacity-80"},Kr={class:"text-center italic relative text-lg sm:text-xl mt-[-15px] text-sky-700 dark:text-blue-200"},Ae=A({__name:"SectionTitle",props:{main:String,sub:String},setup(e){return(n,r)=>(P(),T("div",Zr,[c("div",Hr,te(e.main),1),c("div",Kr,te(e.sub),1)]))}}),Jr={class:"flex flex-col md:flex-row md:h-55 p-0"},Gr=["src"],qr={class:"text-xl font-bold mb-2"},Qr=A({__name:"ProjectCard",props:{imageSrc:{},title:{},description:{},imageOnRight:{type:Boolean}},setup(e){const n=hn(),r=e;function o(l){return l.length>100?l.slice(0,100)+"...":l}function i(){const l={社团简介:"ClubIntro",卫津路校区复刻项目:"WeijinluProject",北洋园校区复刻项目:"BeiyangyuanProject",运营周报:"WeeklyReport",新闻报道:"NewsReport"};n.push({name:l[r.title]})}return(l,z)=>(P(),T("div",{onClick:i,class:"card border border-solid border-zinc-200 rounded-lg shadow-lg border-opacity-20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-white bg-white transition-all duration-500 ease-in-out hover:scale-105 lg:w-4/5 max-w-[780px] box-border"},[c("div",Jr,[c("div",{class:De(["w-full md:w-1/2",{"md:order-2":l.imageOnRight,"order-1":!l.imageOnRight}])},[c("img",{src:r.imageSrc,class:De(["w-full h-full object-cover",{"rounded-t-lg md:rounded-l-lg md:rounded-tr-none":!l.imageOnRight,"rounded-t-lg md:rounded-r-lg md:rounded-tl-none":l.imageOnRight}])},null,10,Gr)],2),c("div",{class:De(["w-full md:w-1/2 px-6 py-4 min-h-40 text-black dark:text-white",{"order-1":l.imageOnRight,"order-2":!l.imageOnRight}])},[c("h2",qr,te(r.title),1),c("p",null,te(o(r.description)),1)],2)])]))}}),es=[{imageSrc:"server/tianda1.png",title:"社团简介",description:"天津大学卫津路校区复刻项目社团介绍"},{imageSrc:"building/图书馆.png",title:"卫津路校区复刻项目",description:"卫津路校区标志性建筑数字化复刻工程"},{imageSrc:"building/北洋广场.png",title:"北洋园校区复刻项目",description:"北洋园校区核心区域三维建模与场景还原"},{imageSrc:"server/tianda2.png",title:"运营周报",description:"复刻项目每周进度与技术指标报告"},{imageSrc:"server/tianda2.png",title:"新闻报道",description:"项目进展与校园文化传承动态资讯"}],ts=["eg/1.png","eg/2.png","eg/0.png","eg/5.png","eg/7.png","eg/8.png"],ns=[{imageSrc:"building/eastDoor.png",title:"东大门",description:"北洋"},{imageSrc:"building/shiShi.png",title:"北洋广场",description:"实事求是"},{imageSrc:"building/胡.png",title:"求是亭",description:"求真务实"},{imageSrc:"building/水塔.png",title:"校史馆",description:"百卅天大"}],Fe={server:es,carousel:ts,building:ns},rs={class:"servers-container sm:w-85% box-border"},ss={class:"grid place-items-center"},os=A({__name:"ProjectCards",setup(e){const n=N(Fe.server);return(r,o)=>(P(),T("div",rs,[c("div",ss,[(P(!0),T(Ue,null,Le(n.value,(i,l)=>(P(),Be(Qr,{key:l,imageSrc:i.imageSrc,title:i.title,description:i.description,imageOnRight:l%2===1},null,8,["imageSrc","title","description","imageOnRight"]))),128))])]))}}),as=Y(os,[["__scopeId","data-v-1b2785fa"]]),is={class:"component p-4"},ls={class:"flex justify-center items-center"},us={class:"text-2xl font-semibold mb-2 text-center mt-5 text-zinc-800 dark:text-blue-400"},cs={class:"text-center text-sm dark:text-blue-300"},ds=A({__name:"FeaturedItem",props:{title:{type:String,required:!0},description:{type:String,required:!0},imageSrc:{type:String,required:!0}},setup(e){return(n,r)=>(P(),T("div",is,[c("div",ls,[c("div",{class:"bg-cover w-full aspect-[1/0.55] rounded-lg hover:scale-105 transition-all duration-300 border-white dark:border-zinc-900",style:mt({backgroundImage:`url(${e.imageSrc})`})},null,4)]),c("h2",us,te(e.title),1),c("p",cs,te(e.description),1)]))}}),fs={class:"building-container"},ps={class:"grid",style:{gridTemplateColumns:"repeat(auto-fit, minmax(250px, 1fr))"}},vs=A({__name:"FeaturedItems",setup(e){const n=N(Fe.building);return(r,o)=>(P(),T("div",fs,[c("div",ps,[(P(!0),T(Ue,null,Le(n.value,(i,l)=>(P(),Be(ds,{key:l,imageSrc:i.imageSrc,title:i.title,description:i.description},null,8,["imageSrc","title","description"]))),128))])]))}}),xs=Y(vs,[["__scopeId","data-v-342f42e6"]]),ms=["src"],gs=A({__name:"Carousel",setup(e){const n=N(1),r=Fe.carousel;function o(){n.value=window.innerWidth>768?3:1}return be(()=>{o(),window.addEventListener("resize",o)}),je(()=>{window.removeEventListener("resize",o)}),(i,l)=>(P(),Be(Oe(Mr),{autoplay:"","slides-per-view":n.value,"space-between":20,class:"animate__animated animate__fadeInUp animate__delay-1s"},{default:bn(()=>[(P(!0),T(Ue,null,Le(Oe(r),(z,C)=>(P(),T("img",{key:C,class:"carousel-img",src:z},null,8,ms))),128))]),_:1},8,["slides-per-view"]))}}),hs=Y(gs,[["__scopeId","data-v-3ba978e8"]]),bs={},ws={class:"back-img relative sm:h-[500px] h-[300px] w-screen bg-fixed bg-[50%_80%] bg-auto"};function _s(e,n){return P(),T("div",ws,n[0]||(n[0]=[c("div",{class:"absolute inset-0 bg-opacity-70 z-[0.5]"},null,-1),c("div",{class:"text-white relative"},[c("div",{class:"z-[1] absolute overflow-hidden sm:h-[500px] w-screen h-[300px] p-[30px] pl-15 box-border flex flex-col items-start flex-wrap text-2xl gap-y-3.5"},[c("h1",null,"TJUUS"),c("h2",null,"是一个"),c("h2",null,"人很多"),c("h2",null,"的"),c("h2",null,"社团")])],-1)]))}const ys=Y(bs,[["render",_s],["__scopeId","data-v-90b2e8fe"]]),Ss="/TJUUS/icon/bili.png",Cs={},Rs={class:"follow-container"};function zs(e,n){return P(),T("div",Rs,n[0]||(n[0]=[c("div",{class:"overlay"},[c("h1",null,"关注我们!!!!!"),c("p",null,[c("a",{href:"https://space.bilibili.com/1343371808",target:"_blank",class:"text-white flex items-center justify-center decoration-none"},[c("img",{src:Ss,alt:"bilibili Logo",class:"h-7 mr-2"}),Ve(" bilibili ")])])],-1)]))}const ks=Y(Cs,[["render",zs],["__scopeId","data-v-adb5bdbb"]]),Ps=A({__name:"Creeper",setup(e){const{width:n,height:r}=yn(),o=N(null),{elementX:i,elementY:l}=Sn(o),{width:z,height:C}=Cn(o),_=new Rn,m=new zn(75,window.innerWidth/window.innerHeight,.1,1e3),d=new kn;d.setSize(1,1);const w=new Pn;let k=null;be(()=>{if(o.value){o.value.appendChild(d.domElement);const D=o.value.clientWidth,b=o.value.clientHeight;d.setSize(D,b),m.aspect=D/b,m.updateProjectionMatrix(),m.position.z=25,d.setClearColor(0,0);const y=new $n(16777215,3);_.add(y);const $=new st(16777215,3);$.position.set(5,5,5),_.add($);const V=new st(16777215,3);V.position.set(-5,-5,-5),_.add(V),w.load("model/scene.gltf",I=>{k=I.scene,k.rotation.z=3*Math.PI/13,_.add(I.scene),M();const ne=z.value,H=C.value;d.setSize(ne,H),m.aspect=ne/H,m.updateProjectionMatrix()},void 0,I=>{console.error("An error happened",I)})}});function M(){window.requestAnimationFrame(M),d.render(_,m)}return Z([i,l],([D,b])=>{if(k){const y=n.value/2,$=r.value/2,V=D/y,I=b/$;In.to(k.rotation,{y:(V*Math.PI-.3)/16,x:(I*Math.PI+.3)/8,duration:.9,ease:"power2.out"})}}),Z([C,z],([D,b])=>{const y=D,$=b;d.setSize(y,$),m.aspect=y/$,m.updateProjectionMatrix()}),(D,b)=>(P(),T("div",{class:"creeper min-w-[150px] min-h-[150px] box-border",ref_key:"creeperContainer",ref:o},null,512))}}),$s={},Is={class:"bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 text-white p-5 relative w-full"};function Ts(e,n){return P(),T("footer",Is,n[0]||(n[0]=[wn('<div class="max-w-[1200px] mx-auto flex flex-row items-center"><nav class="flex flex-col items-start"><a href="#" target="_blank" class="text-white hover:underline my-1">友链1</a><a href="#" target="_blank" class="text-white hover:underline my-1">友链2</a><a href="#" target="_blank" class="text-white hover:underline my-1">友链3</a></nav><div class="absolute inset-0 flex items-center justify-center"><p class="text-lg">TJUUS 2025</p></div></div>',1)]))}const Ds=Y($s,[["render",Ts]]),Ns={class:"min-h-screen"},Es={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-[85%] py-8"},As={class:"grid sc box-border justify-center items-center sm:mx-7 mx-9"},Vs={class:"grid-cols-1"},Os={class:"h-auto w-0 justify-self-start creeper animate__animated animate__fadeInRight animate__delay-2s"},Ms={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-0 w-80% py-8"},js={class:"intro sm:mx-10 md:mx-20 lg:mx-30 mx-5 w-80% py-8"},Us=A({__name:"Home",setup(e){return(n,r)=>(P(),T("div",Ns,[E(Br),c("section",Es,[E(Xr,{class:"developing"})]),E(Oe(Tn),{dashed:!0}),c("section",As,[c("div",Vs,[E(as,{class:"row lg:w-80%"})]),c("div",Os,[E(Ps,{class:"sm:h-[350px] sm:w-[300px] md:h-[400px] md:w-[400px] lg:h-[550px] lg:w-[550px] h-[260px] w-[250px]"})])]),c("section",Ms,[E(Ae,{class:"row my",main:"我们是",sub:"TJUUS"})]),E(ys),c("section",js,[E(Ae,{class:"row my",main:"建设成果",sub:"探索Minecraft的无限可能"}),E(xs,{class:"row"}),E(Ae,{class:"row my-5",main:"我们的伙伴",sub:"联合"}),E(hs,{class:"row my-5"})]),E(ks,{class:"mt"}),E(Ds)]))}}),Fs=Y(Us,[["__scopeId","data-v-a3cda8ff"]]);export{Fs as default};
